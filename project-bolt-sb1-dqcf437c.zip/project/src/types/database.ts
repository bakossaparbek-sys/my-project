export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export interface Database {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string
          email: string
          full_name: string
          avatar_url: string
          role: 'buyer' | 'seller' | 'admin'
          created_at: string
          updated_at: string
        }
        Insert: {
          id: string
          email: string
          full_name?: string
          avatar_url?: string
          role?: 'buyer' | 'seller' | 'admin'
        }
        Update: {
          email?: string
          full_name?: string
          avatar_url?: string
          role?: 'buyer' | 'seller' | 'admin'
        }
      }
      categories: {
        Row: {
          id: string
          name_kz: string
          name_ru: string
          slug: string
          icon: string
          parent_id: string | null
          created_at: string
        }
        Insert: {
          name_kz: string
          name_ru?: string
          slug: string
          icon?: string
          parent_id?: string | null
        }
        Update: {
          name_kz?: string
          name_ru?: string
          slug?: string
          icon?: string
          parent_id?: string | null
        }
      }
      products: {
        Row: {
          id: string
          title: string
          description: string
          price: number
          compare_price: number
          images: string[]
          category_id: string | null
          seller_id: string | null
          stock: number
          rating: number
          reviews_count: number
          is_active: boolean
          created_at: string
          updated_at: string
        }
        Insert: {
          title: string
          description?: string
          price: number
          compare_price?: number
          images?: string[]
          category_id?: string | null
          seller_id?: string | null
          stock?: number
          rating?: number
          reviews_count?: number
          is_active?: boolean
        }
        Update: {
          title?: string
          description?: string
          price?: number
          compare_price?: number
          images?: string[]
          category_id?: string | null
          seller_id?: string | null
          stock?: number
          rating?: number
          reviews_count?: number
          is_active?: boolean
        }
      }
      cart_items: {
        Row: {
          id: string
          user_id: string
          product_id: string
          quantity: number
          created_at: string
          updated_at: string
        }
        Insert: {
          user_id: string
          product_id: string
          quantity?: number
        }
        Update: {
          quantity?: number
        }
      }
      favorites: {
        Row: {
          id: string
          user_id: string
          product_id: string
          created_at: string
        }
        Insert: {
          user_id: string
          product_id: string
        }
      }
      reviews: {
        Row: {
          id: string
          product_id: string
          user_id: string
          rating: number
          comment: string
          created_at: string
          updated_at: string
        }
        Insert: {
          product_id: string
          user_id: string
          rating: number
          comment?: string
        }
        Update: {
          rating?: number
          comment?: string
        }
      }
      chat_rooms: {
        Row: {
          id: string
          product_id: string
          buyer_id: string
          seller_id: string
          created_at: string
          updated_at: string
        }
        Insert: {
          product_id: string
          buyer_id: string
          seller_id: string
        }
      }
      chat_messages: {
        Row: {
          id: string
          room_id: string
          sender_id: string
          message: string
          read_at: string | null
          created_at: string
        }
        Insert: {
          room_id: string
          sender_id: string
          message: string
        }
      }
      orders: {
        Row: {
          id: string
          user_id: string
          status: 'pending' | 'processing' | 'shipped' | 'delivered' | 'cancelled'
          total: number
          shipping_address: Json
          payment_status: 'pending' | 'paid' | 'failed' | 'refunded'
          payment_intent_id: string
          created_at: string
          updated_at: string
        }
        Insert: {
          user_id: string
          status?: 'pending' | 'processing' | 'shipped' | 'delivered' | 'cancelled'
          total: number
          shipping_address?: Json
          payment_status?: 'pending' | 'paid' | 'failed' | 'refunded'
          payment_intent_id?: string
        }
        Update: {
          status?: 'pending' | 'processing' | 'shipped' | 'delivered' | 'cancelled'
          total?: number
          shipping_address?: Json
          payment_status?: 'pending' | 'paid' | 'failed' | 'refunded'
          payment_intent_id?: string
        }
      }
      order_items: {
        Row: {
          id: string
          order_id: string
          product_id: string | null
          quantity: number
          price: number
          created_at: string
        }
        Insert: {
          order_id: string
          product_id: string | null
          quantity: number
          price: number
        }
      }
    }
  }
}

export type Profile = Database['public']['Tables']['profiles']['Row']
export type Category = Database['public']['Tables']['categories']['Row']
export type Product = Database['public']['Tables']['products']['Row']
export type CartItem = Database['public']['Tables']['cart_items']['Row']
export type Favorite = Database['public']['Tables']['favorites']['Row']
export type Review = Database['public']['Tables']['reviews']['Row']
export type ChatRoom = Database['public']['Tables']['chat_rooms']['Row']
export type ChatMessage = Database['public']['Tables']['chat_messages']['Row']
export type Order = Database['public']['Tables']['orders']['Row']
export type OrderItem = Database['public']['Tables']['order_items']['Row']

export interface ProductWithDetails extends Product {
  category?: Category
  seller?: Profile
  is_favorite?: boolean
}

export interface CartItemWithProduct extends CartItem {
  product: ProductWithDetails
}

export interface ReviewWithUser extends Review {
  user: Profile
}

export interface ChatRoomWithDetails extends ChatRoom {
  product?: Product
  buyer?: Profile
  seller?: Profile
  last_message?: ChatMessage
  unread_count?: number
}
