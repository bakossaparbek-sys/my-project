import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowRight, Sparkles, TrendingUp, Star, ChevronLeft, ChevronRight } from 'lucide-react';
import { supabase } from '../lib/supabase';
import type { ProductWithDetails, Category } from '../types/database';

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: { staggerChildren: 0.1 }
  }
};

const item = {
  hidden: { opacity: 0, y: 20 },
  show: { opacity: 1, y: 0 }
};

export default function Home() {
  const [categories, setCategories] = useState<Category[]>([]);
  const [featuredProducts, setFeaturedProducts] = useState<ProductWithDetails[]>([]);
  const [loading, setLoading] = useState(true);
  const [currentSlide, setCurrentSlide] = useState(0);

  const heroSlides = [
    {
      title: 'Жаңа коллекция',
      subtitle: '2024 көктем-жаз',
      description: 'Ең соңғы трендтер мен сәнді заттар',
      image: 'https://images.pexels.com/photos/16614797/pexels-photo-16614797.jpeg?auto=compress&cs=tinysrgb&w=1260',
      cta: 'Қарау'
    },
    {
      title: 'Технологиялар әлемі',
      subtitle: 'Заманауи гаджеттер',
      description: 'Ең жаңа смартфондар мен ноутбуктар',
      image: 'https://images.pexels.com/photos/7915437/pexels-photo-7915437.jpeg?auto=compress&cs=tinysrgb&w=1260',
      cta: 'Сатып алу'
    },
    {
      title: 'Үй және бақша',
      subtitle: 'Тұрмыстық техникалар',
      description: 'Үйіңізді жайлы етіңіз',
      image: 'https://images.pexels.com/photos/1571460/pexels-photo-1571460.jpeg?auto=compress&cs=tinysrgb&w=1260',
      cta: 'Арнайы ұсыныс'
    }
  ];

  useEffect(() => {
    fetchCategories();
    fetchFeaturedProducts();
  }, []);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % heroSlides.length);
    }, 6000);
    return () => clearInterval(timer);
  }, [heroSlides.length]);

  async function fetchCategories() {
    const { data } = await supabase
      .from('categories')
      .select('*')
      .order('name_kz');
    if (data) setCategories(data);
  }

  async function fetchFeaturedProducts() {
    const { data } = await supabase
      .from('products')
      .select(`
        *,
        category:categories(*),
        seller:profiles(*)
      `)
      .eq('is_active', true)
      .gt('rating', 4)
      .order('created_at', { ascending: false })
      .limit(8);
    if (data) setFeaturedProducts(data as ProductWithDetails[]);
    setLoading(false);
  }

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative h-[60vh] md:h-[70vh] overflow-hidden">
        {heroSlides.map((slide, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0 }}
            animate={{
              opacity: currentSlide === index ? 1 : 0,
              scale: currentSlide === index ? 1 : 1.1
            }}
            transition={{ duration: 1 }}
            className="absolute inset-0"
          >
            <div className="absolute inset-0 bg-gradient-to-r from-slate-900/90 via-slate-900/70 to-transparent z-10" />
            <img
              src={slide.image}
              alt={slide.title}
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 z-20 flex items-center">
              <div className="container-custom">
                <motion.div
                  initial={{ opacity: 0, x: -50 }}
                  animate={{
                    opacity: currentSlide === index ? 1 : 0,
                    x: currentSlide === index ? 0 : -50
                  }}
                  transition={{ delay: 0.3, duration: 0.6 }}
                  className="max-w-xl"
                >
                  <span className="inline-flex items-center gap-2 badge badge-primary mb-4">
                    <Sparkles className="w-3 h-3" />
                    {slide.subtitle}
                  </span>
                  <h1 className="heading-xl text-white mb-4">{slide.title}</h1>
                  <p className="text-gray-300 text-lg mb-6">{slide.description}</p>
                  <Link to="/catalog">
                    <motion.button
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      className="btn-primary inline-flex items-center gap-2"
                    >
                      {slide.cta}
                      <ArrowRight className="w-4 h-4" />
                    </motion.button>
                  </Link>
                </motion.div>
              </div>
            </div>
          </motion.div>
        ))}

        {/* Slide Indicators */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 z-30 flex gap-2">
          {heroSlides.map((_, index) => (
            <button
              key={index}
              onClick={() => setCurrentSlide(index)}
              className={`w-12 h-1.5 rounded-full transition-all ${
                currentSlide === index ? 'bg-blue-500' : 'bg-white/30'
              }`}
            />
          ))}
        </div>

        {/* Slide Navigation Buttons */}
        <button
          onClick={() => setCurrentSlide((prev) => (prev - 1 + heroSlides.length) % heroSlides.length)}
          className="absolute left-4 top-1/2 -translate-y-1/2 z-30 p-2 glass-button rounded-full"
        >
          <ChevronLeft className="w-6 h-6" />
        </button>
        <button
          onClick={() => setCurrentSlide((prev) => (prev + 1) % heroSlides.length)}
          className="absolute right-4 top-1/2 -translate-y-1/2 z-30 p-2 glass-button rounded-full"
        >
          <ChevronRight className="w-6 h-6" />
        </button>
      </section>

      {/* Categories Section */}
      <section className="py-16 md:py-20">
        <div className="container-custom">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="heading-lg mb-4">Санаттар</h2>
            <p className="text-gray-400 max-w-2xl mx-auto">
              Мыңдаған тауарлар мен санаттарды зерттеңіз
            </p>
          </motion.div>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-8 gap-4">
            {categories.map((category, index) => (
              <motion.div
                key={category.id}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.05 }}
              >
                <Link
                  to={`/catalog?category=${category.slug}`}
                  className="glass-card text-center p-4 block hover:border-blue-500/30"
                >
                  <div className="w-14 h-14 mx-auto mb-3 rounded-xl bg-gradient-to-br from-blue-500/20 to-cyan-500/20 flex items-center justify-center">
                    <TrendingUp className="w-7 h-7 text-blue-400" />
                  </div>
                  <span className="text-sm font-medium">{category.name_kz}</span>
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-16 md:py-20 bg-gradient-to-b from-transparent via-blue-950/20 to-transparent">
        <div className="container-custom">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="flex items-center justify-between mb-12"
          >
            <div>
              <h2 className="heading-lg mb-2">Танымал тауарлар</h2>
              <p className="text-gray-400">Ең жақсы бағалар мен сапа</p>
            </div>
            <Link to="/catalog">
              <motion.button
                whileHover={{ scale: 1.05, x: 5 }}
                whileTap={{ scale: 0.95 }}
                className="btn-secondary inline-flex items-center gap-2"
              >
                Барлығы
                <ArrowRight className="w-4 h-4" />
              </motion.button>
            </Link>
          </motion.div>

          {loading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {[...Array(4)].map((_, i) => (
                <div key={i} className="glass-card">
                  <div className="skeleton aspect-square rounded-xl mb-4" />
                  <div className="skeleton h-4 w-3/4 mb-2" />
                  <div className="skeleton h-4 w-1/2" />
                </div>
              ))}
            </div>
          ) : (
            <motion.div
              variants={container}
              initial="hidden"
              whileInView="show"
              viewport={{ once: true }}
              className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6"
            >
              {featuredProducts.map((product) => (
                <motion.div key={product.id} variants={item}>
                  <ProductCard product={product} />
                </motion.div>
              ))}
            </motion.div>
          )}
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 md:py-20">
        <div className="container-custom">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="heading-lg mb-4">Неге біз?</h2>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                icon: Sparkles,
                title: 'Сапа кепілдігі',
                description: 'Барлық тауарлар сапа бақылауынан өтеді. Кез келген ақау кезінде толық қайтару.'
              },
              {
                icon: TrendingUp,
                title: 'Бәсекелес бағалар',
                description: 'Біз нарықтағы ең жақсы бағаларды ұсынамыз. Баға салыстыру қол жетімді.'
              },
              {
                icon: Star,
                title: 'Тұрақты сыйақылар',
                description: 'Әр сатып алым үшін бонус ұпайлары. Оларды жеңілдіктерге айырбастаңыз.'
              }
            ].map((feature, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="glass-card text-center"
              >
                <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-blue-500 to-cyan-500 mx-auto mb-4 flex items-center justify-center">
                  <feature.icon className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
                <p className="text-gray-400">{feature.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Newsletter Section */}
      <section className="py-16 md:py-20">
        <div className="container-custom">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="glass-card p-8 md:p-12 text-center max-w-3xl mx-auto shadow-glow-lg"
          >
            <h2 className="heading-md mb-4">Жаңалықтарға жазылыңыз</h2>
            <p className="text-gray-400 mb-6">
              Арнайы ұсыныстар мен жаңалықтарды бірінші болып алыңыз
            </p>
            <form className="flex flex-col sm:flex-row gap-3 max-w-md mx-auto">
              <input
                type="email"
                placeholder="email@example.com"
                className="glass-input flex-1"
              />
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                type="submit"
                className="btn-primary whitespace-nowrap"
              >
                Жазылу
              </motion.button>
            </form>
          </motion.div>
        </div>
      </section>
    </div>
  );
}

function ProductCard({ product }: { product: ProductWithDetails }) {
  return (
    <Link to={`/product/${product.id}`}>
      <motion.div
        whileHover={{ y: -5 }}
        className="product-card"
      >
        <div className="relative aspect-square rounded-xl overflow-hidden mb-4 bg-slate-800/50">
          {product.images[0] ? (
            <img
              src={product.images[0]}
              alt={product.title}
              className="product-card-image"
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center">
              <Sparkles className="w-16 h-16 text-gray-600" />
            </div>
          )}
          {product.compare_price > product.price && (
            <div className="absolute top-2 left-2 badge badge-danger">
              -{Math.round((1 - product.price / product.compare_price) * 100)}%
            </div>
          )}
        </div>
        <h3 className="font-medium mb-1 line-clamp-2">{product.title}</h3>
        <div className="flex items-center gap-1 mb-2">
          <Star className="w-4 h-4 text-yellow-400 fill-yellow-400" />
          <span className="text-sm text-gray-400">{product.rating.toFixed(1)}</span>
          <span className="text-sm text-gray-600">({product.reviews_count})</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xl font-bold text-gradient">{product.price.toLocaleString()} ₸</span>
          {product.compare_price > product.price && (
            <span className="text-sm text-gray-500 line-through">
              {product.compare_price.toLocaleString()} ₸
            </span>
          )}
        </div>
      </motion.div>
    </Link>
  );
}
