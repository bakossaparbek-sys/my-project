import { useState, useEffect } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Search,
  Filter,
  X,
  Star,
  ChevronDown,
  Grid,
  List,
  Sparkles,
  SlidersHorizontal
} from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../lib/auth-context';
import type { ProductWithDetails, Category } from '../types/database';

const sortOptions = [
  { value: 'newest', label: 'Жаңалары' },
  { value: 'price_asc', label: 'Баға: арзаннан қымбатқа' },
  { value: 'price_desc', label: 'Баға: қымбаттан арзанға' },
  { value: 'rating', label: 'Рейтинг' },
  { value: 'popular', label: 'Танымалдық' }
];

export default function Catalog() {
  const [searchParams, setSearchParams] = useSearchParams();
  const { user } = useAuth();
  const [products, setProducts] = useState<ProductWithDetails[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [mobileFilterOpen, setMobileFilterOpen] = useState(false);

  const [filters, setFilters] = useState({
    search: searchParams.get('search') || '',
    category: searchParams.get('category') || '',
    minPrice: searchParams.get('minPrice') || '',
    maxPrice: searchParams.get('maxPrice') || '',
    rating: searchParams.get('rating') || '',
    sort: searchParams.get('sort') || 'newest',
    view: (searchParams.get('view') as 'grid' | 'list') || 'grid'
  });

  const [priceRange, setPriceRange] = useState({ min: '', max: '' });

  useEffect(() => {
    fetchCategories();
  }, []);

  useEffect(() => {
    fetchProducts();
  }, [filters, user]);

  useEffect(() => {
    const params = new URLSearchParams();
    Object.entries(filters).forEach(([key, value]) => {
      if (value) params.set(key, value);
    });
    setSearchParams(params);
  }, [filters]);

  async function fetchCategories() {
    const { data } = await supabase
      .from('categories')
      .select('*')
      .order('name_kz');
    if (data) setCategories(data);
  }

  async function fetchProducts() {
    setLoading(true);
    let query = supabase
      .from('products')
      .select(`
        *,
        category:categories(*),
        seller:profiles(*)
      `)
      .eq('is_active', true);

    if (filters.search) {
      query = query.ilike('title', `%${filters.search}%`);
    }

    if (filters.category) {
      const category = categories.find(c => c.slug === filters.category);
      if (category) {
        query = query.eq('category_id', category.id);
      }
    }

    if (filters.minPrice) {
      query = query.gte('price', parseFloat(filters.minPrice));
    }

    if (filters.maxPrice) {
      query = query.lte('price', parseFloat(filters.maxPrice));
    }

    if (filters.rating) {
      query = query.gte('rating', parseFloat(filters.rating));
    }

    switch (filters.sort) {
      case 'price_asc':
        query = query.order('price', { ascending: true });
        break;
      case 'price_desc':
        query = query.order('price', { ascending: false });
        break;
      case 'rating':
        query = query.order('rating', { ascending: false });
        break;
      case 'popular':
        query = query.order('reviews_count', { ascending: false });
        break;
      default:
        query = query.order('created_at', { ascending: false });
    }

    const { data } = await query;
    if (data) {
      let productsData = data as ProductWithDetails[];

      if (user) {
        const productIds = productsData.map(p => p.id);
        const { data: favorites } = await supabase
          .from('favorites')
          .select('product_id')
          .eq('user_id', user.id)
          .in('product_id', productIds);

        const favoriteIds = new Set(favorites?.map(f => f.product_id));
        productsData = productsData.map(p => ({
          ...p,
          is_favorite: favoriteIds.has(p.id)
        }));
      }

      setProducts(productsData);
    }
    setLoading(false);
  }

  function updateFilter(key: string, value: string) {
    setFilters(prev => ({ ...prev, [key]: value }));
  }

  function clearFilters() {
    setFilters({
      search: '',
      category: '',
      minPrice: '',
      maxPrice: '',
      rating: '',
      sort: 'newest',
      view: filters.view
    });
    setPriceRange({ min: '', max: '' });
  }

  function applyPriceFilter() {
    updateFilter('minPrice', priceRange.min);
    updateFilter('maxPrice', priceRange.max);
    setMobileFilterOpen(false);
  }

  const activeFiltersCount = [
    filters.search,
    filters.category,
    filters.minPrice,
    filters.maxPrice,
    filters.rating
  ].filter(Boolean).length;

  return (
    <div className="py-8 md:py-12">
      <div className="container-custom">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h1 className="heading-lg mb-4">Каталог</h1>
          <div className="flex flex-col lg:flex-row gap-4">
            {/* Search */}
            <div className="flex-1 relative">
              <Search className="input-icon-left w-5 h-5" />
              <input
                type="text"
                value={filters.search}
                onChange={(e) => updateFilter('search', e.target.value)}
                placeholder="Тауар іздеу..."
                className="glass-input pl-10"
              />
            </div>

            {/* Sort & View Controls */}
            <div className="flex gap-2">
              <div className="relative">
                <select
                  value={filters.sort}
                  onChange={(e) => updateFilter('sort', e.target.value)}
                  className="glass-input pr-10 appearance-none cursor-pointer"
                >
                  {sortOptions.map(option => (
                    <option key={option.value} value={option.value} className="bg-slate-900">
                      {option.label}
                    </option>
                  ))}
                </select>
                <ChevronDown className="input-icon-right w-4 h-4 pointer-events-none" />
              </div>

              <div className="flex glass-light rounded-xl overflow-hidden">
                <button
                  onClick={() => updateFilter('view', 'grid')}
                  className={`p-3 transition-colors ${filters.view === 'grid' ? 'bg-blue-500/30 text-blue-300' : ''}`}
                >
                  <Grid className="w-5 h-5" />
                </button>
                <button
                  onClick={() => updateFilter('view', 'list')}
                  className={`p-3 transition-colors ${filters.view === 'list' ? 'bg-blue-500/30 text-blue-300' : ''}`}
                >
                  <List className="w-5 h-5" />
                </button>
              </div>

              <button
                onClick={() => setMobileFilterOpen(true)}
                className="lg:hidden btn-secondary relative"
              >
                <SlidersHorizontal className="w-5 h-5" />
                {activeFiltersCount > 0 && (
                  <span className="absolute -top-1 -right-1 w-5 h-5 bg-blue-500 rounded-full text-xs font-bold flex items-center justify-center">
                    {activeFiltersCount}
                  </span>
                )}
              </button>
            </div>
          </div>
        </motion.div>

        <div className="flex gap-8">
          {/* Desktop Sidebar Filters */}
          <aside className="hidden lg:block w-64 flex-shrink-0">
            <div className="glass-card sticky top-24">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-semibold flex items-center gap-2">
                  <Filter className="w-4 h-4" />
                  Сүзгілер
                </h3>
                {activeFiltersCount > 0 && (
                  <button
                    onClick={clearFilters}
                    className="text-sm text-blue-400 hover:text-blue-300 transition-colors"
                  >
                    Тазалау
                  </button>
                )}
              </div>

              {/* Categories */}
              <div className="mb-6">
                <h4 className="font-medium mb-3 text-gray-300">Санаттар</h4>
                <div className="space-y-2">
                  {categories.map(category => (
                    <button
                      key={category.id}
                      onClick={() => updateFilter('category', filters.category === category.slug ? '' : category.slug)}
                      className={`category-chip w-full text-left ${filters.category === category.slug ? 'category-chip-active' : ''}`}
                    >
                      {category.name_kz}
                    </button>
                  ))}
                </div>
              </div>

              {/* Price Range */}
              <div className="mb-6">
                <h4 className="font-medium mb-3 text-gray-300">Баға диапозоны</h4>
                <div className="flex gap-2">
                  <input
                    type="number"
                    value={priceRange.min}
                    onChange={(e) => setPriceRange(prev => ({ ...prev, min: e.target.value }))}
                    placeholder="Мин"
                    className="glass-input text-sm"
                  />
                  <input
                    type="number"
                    value={priceRange.max}
                    onChange={(e) => setPriceRange(prev => ({ ...prev, max: e.target.value }))}
                    placeholder="Макс"
                    className="glass-input text-sm"
                  />
                </div>
                <button
                  onClick={applyPriceFilter}
                  className="btn-secondary w-full mt-2 text-sm"
                >
                  Қолдану
                </button>
              </div>

              {/* Rating */}
              <div>
                <h4 className="font-medium mb-3 text-gray-300">Рейтинг</h4>
                <div className="space-y-2">
                  {[4, 3, 2].map(rating => (
                    <button
                      key={rating}
                      onClick={() => updateFilter('rating', filters.rating === String(rating) ? '' : String(rating))}
                      className={`category-chip w-full text-left flex items-center gap-1 ${filters.rating === String(rating) ? 'category-chip-active' : ''}`}
                    >
                      <Star className="w-4 h-4 text-yellow-400 fill-yellow-400" />
                      <span>{rating}+ жұлдыз</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </aside>

          {/* Main Content */}
          <main className="flex-1">
            {/* Active Filters */}
            {activeFiltersCount > 0 && (
              <div className="flex flex-wrap gap-2 mb-4">
                {filters.search && (
                  <span className="badge badge-primary flex items-center gap-1">
                    "{filters.search}"
                    <button onClick={() => updateFilter('search', '')}>
                      <X className="w-3 h-3" />
                    </button>
                  </span>
                )}
                {filters.category && (
                  <span className="badge badge-primary flex items-center gap-1">
                    {categories.find(c => c.slug === filters.category)?.name_kz}
                    <button onClick={() => updateFilter('category', '')}>
                      <X className="w-3 h-3" />
                    </button>
                  </span>
                )}
                {(filters.minPrice || filters.maxPrice) && (
                  <span className="badge badge-primary flex items-center gap-1">
                    {filters.minPrice || '0'} - {filters.maxPrice || '∞'} ₸
                    <button onClick={() => {
                      updateFilter('minPrice', '');
                      updateFilter('maxPrice', '');
                      setPriceRange({ min: '', max: '' });
                    }}>
                      <X className="w-3 h-3" />
                    </button>
                  </span>
                )}
                {filters.rating && (
                  <span className="badge badge-primary flex items-center gap-1">
                    {filters.rating}+ жұлдыз
                    <button onClick={() => updateFilter('rating', '')}>
                      <X className="w-3 h-3" />
                    </button>
                  </span>
                )}
              </div>
        )}

            {/* Products Grid/List */}
            {loading ? (
              <div className={filters.view === 'grid'
                ? 'grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-6'
                : 'space-y-4'
              }>
                {[...Array(6)].map((_, i) => (
                  <div key={i} className="glass-card">
                    {filters.view === 'grid' ? (
                      <>
                        <div className="skeleton aspect-square rounded-xl mb-4" />
                        <div className="skeleton h-4 w-3/4 mb-2" />
                        <div className="skeleton h-4 w-1/2" />
                      </>
                    ) : (
                      <div className="flex gap-4">
                        <div className="skeleton w-32 h-32 rounded-xl flex-shrink-0" />
                        <div className="flex-1">
                          <div className="skeleton h-4 w-3/4 mb-2" />
                          <div className="skeleton h-4 w-1/2 mb-2" />
                          <div className="skeleton h-4 w-1/4" />
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            ) : products.length === 0 ? (
              <div className="text-center py-12">
                <Sparkles className="w-16 h-16 text-gray-600 mx-auto mb-4" />
                <p className="text-gray-400">Тауарлар табылмады</p>
                <button onClick={clearFilters} className="btn-secondary mt-4">
                  Сүзгілерді тазалау
                </button>
              </div>
            ) : (
              <div className={filters.view === 'grid'
                ? 'grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-6'
                : 'space-y-4'
              }>
                {products.map((product, index) => (
                  <motion.div
                    key={product.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.05 }}
                  >
                    <ProductCard
                      product={product}
                      view={filters.view as 'grid' | 'list'}
                    />
                  </motion.div>
                ))}
              </div>
            )}
          </main>
        </div>
      </div>

      {/* Mobile Filter Modal */}
      <AnimatePresence>
        {mobileFilterOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm lg:hidden"
            onClick={() => setMobileFilterOpen(false)}
          >
            <motion.div
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'tween' }}
              className="absolute right-0 top-0 bottom-0 w-80 max-w-full glass-dark p-6 overflow-y-auto"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex items-center justify-between mb-6">
                <h3 className="font-semibold text-lg">Сүзгілер</h3>
                <button onClick={() => setMobileFilterOpen(false)}>
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="space-y-6">
                <div>
                  <h4 className="font-medium mb-3">Санаттар</h4>
                  <div className="space-y-2">
                    {categories.map(category => (
                      <button
                        key={category.id}
                        onClick={() => updateFilter('category', filters.category === category.slug ? '' : category.slug)}
                        className={`category-chip w-full text-left ${filters.category === category.slug ? 'category-chip-active' : ''}`}
                      >
                        {category.name_kz}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <h4 className="font-medium mb-3">Баға диапозоны</h4>
                  <div className="flex gap-2">
                    <input
                      type="number"
                      value={priceRange.min}
                      onChange={(e) => setPriceRange(prev => ({ ...prev, min: e.target.value }))}
                      placeholder="Мин"
                      className="glass-input text-sm"
                    />
                    <input
                      type="number"
                      value={priceRange.max}
                      onChange={(e) => setPriceRange(prev => ({ ...prev, max: e.target.value }))}
                      placeholder="Макс"
                      className="glass-input text-sm"
                    />
                  </div>
                </div>

                <div>
                  <h4 className="font-medium mb-3">Рейтинг</h4>
                  <div className="space-y-2">
                    {[4, 3, 2].map(rating => (
                      <button
                        key={rating}
                        onClick={() => updateFilter('rating', filters.rating === String(rating) ? '' : String(rating))}
                        className={`category-chip w-full text-left flex items-center gap-1 ${filters.rating === String(rating) ? 'category-chip-active' : ''}`}
                      >
                        <Star className="w-4 h-4 text-yellow-400 fill-yellow-400" />
                        <span>{rating}+ жұлдыз</span>
                      </button>
                    ))}
                  </div>
                </div>

                <div className="flex gap-3 pt-4 border-t border-white/10">
                  <button
                    onClick={clearFilters}
                    className="btn-secondary flex-1"
                  >
                    Тазалау
                  </button>
                  <button
                    onClick={() => {
                      applyPriceFilter();
                      setMobileFilterOpen(false);
                    }}
                    className="btn-primary flex-1"
                  >
                    Қолдану
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function ProductCard({ product, view }: { product: ProductWithDetails; view: 'grid' | 'list' }) {
  const { user } = useAuth();

  async function toggleFavorite(e: React.MouseEvent) {
    e.preventDefault();
    if (!user) return;

    if (product.is_favorite) {
      await supabase
        .from('favorites')
        .delete()
        .eq('user_id', user.id)
        .eq('product_id', product.id);
    } else {
      await supabase
        .from('favorites')
        .insert({ user_id: user.id, product_id: product.id });
    }
  }

  if (view === 'list') {
    return (
      <Link to={`/product/${product.id}`}>
        <div className="product-card flex gap-4">
          <div className="w-32 h-32 rounded-xl overflow-hidden flex-shrink-0 bg-slate-800/50">
            {product.images[0] ? (
              <img
                src={product.images[0]}
                alt={product.title}
                className="w-full h-full object-cover"
              />
            ) : (
              <div className="w-full h-full flex items-center justify-center">
                <Sparkles className="w-10 h-10 text-gray-600" />
              </div>
            )}
          </div>
          <div className="flex-1 min-w-0">
            <h3 className="font-medium mb-1 truncate">{product.title}</h3>
            <div className="flex items-center gap-1 mb-2">
              <Star className="w-4 h-4 text-yellow-400 fill-yellow-400" />
              <span className="text-sm text-gray-400">{product.rating.toFixed(1)}</span>
              <span className="text-sm text-gray-600">({product.reviews_count})</span>
            </div>
            <p className="text-sm text-gray-500 line-clamp-2 mb-2">{product.description}</p>
            <div className="flex items-center gap-2">
              <span className="text-xl font-bold text-gradient">{product.price.toLocaleString()} ₸</span>
              {product.compare_price > product.price && (
                <span className="text-sm text-gray-500 line-through">
                  {product.compare_price.toLocaleString()} ₸
                </span>
              )}
            </div>
          </div>
        </div>
      </Link>
    );
  }

  return (
    <Link to={`/product/${product.id}`}>
      <div className="product-card relative">
        <button
          onClick={toggleFavorite}
          className="absolute top-3 right-3 z-10 p-2 glass-light rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
        >
          <Star className={`w-4 h-4 ${product.is_favorite ? 'text-red-400 fill-red-400' : ''}`} />
        </button>
        <div className="relative aspect-square rounded-xl overflow-hidden mb-4 bg-slate-800/50">
          {product.images[0] ? (
            <img
              src={product.images[0]}
              alt={product.title}
              className="product-card-image"
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center">
              <Sparkles className="w-16 h-16 text-gray-600" />
            </div>
          )}
          {product.compare_price > product.price && (
            <div className="absolute top-2 left-2 badge badge-danger">
              -{Math.round((1 - product.price / product.compare_price) * 100)}%
            </div>
          )}
        </div>
        <h3 className="font-medium mb-1 line-clamp-2">{product.title}</h3>
        <div className="flex items-center gap-1 mb-2">
          <Star className="w-4 h-4 text-yellow-400 fill-yellow-400" />
          <span className="text-sm text-gray-400">{product.rating.toFixed(1)}</span>
          <span className="text-sm text-gray-600">({product.reviews_count})</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xl font-bold text-gradient">{product.price.toLocaleString()} ₸</span>
          {product.compare_price > product.price && (
            <span className="text-sm text-gray-500 line-through">
              {product.compare_price.toLocaleString()} ₸
            </span>
          )}
        </div>
      </div>
    </Link>
  );
}
