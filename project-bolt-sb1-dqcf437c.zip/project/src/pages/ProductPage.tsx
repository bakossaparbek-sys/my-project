import { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Star,
  ShoppingCart,
  Heart,
  MessageCircle,
  Share2,
  ChevronLeft,
  ChevronRight,
  Minus,
  Plus,
  Sparkles,
  Truck,
  Shield,
  Package,
  User
} from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../lib/auth-context';
import type { ProductWithDetails, ReviewWithUser, Profile } from '../types/database';

export default function ProductPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user, profile } = useAuth();
  const [product, setProduct] = useState<ProductWithDetails | null>(null);
  const [reviews, setReviews] = useState<ReviewWithUser[]>([]);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [loading, setLoading] = useState(true);
  const [showReviewForm, setShowReviewForm] = useState(false);
  const [reviewRating, setReviewRating] = useState(5);
  const [reviewComment, setReviewComment] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const [activeTab, setActiveTab] = useState<'description' | 'reviews'>('description');

  useEffect(() => {
    if (id) {
      fetchProduct();
      fetchReviews();
    }
  }, [id, user]);

  async function fetchProduct() {
    const { data } = await supabase
      .from('products')
      .select(`
        *,
        category:categories(*),
        seller:profiles(*)
      `)
      .eq('id', id)
      .maybeSingle();

    if (data) {
      let productData = data as ProductWithDetails;
      if (user) {
        const { data: favorite } = await supabase
          .from('favorites')
          .select('id')
          .eq('user_id', user.id)
          .eq('product_id', id)
          .maybeSingle();
        productData.is_favorite = !!favorite;
      }
      setProduct(productData);
    }
    setLoading(false);
  }

  async function fetchReviews() {
    const { data } = await supabase
      .from('reviews')
      .select(`
        *,
        user:profiles(*)
      `)
      .eq('product_id', id)
      .order('created_at', { ascending: false });

    if (data) setReviews(data as ReviewWithUser[]);
  }

  async function addToCart(e: React.MouseEvent) {
    e.stopPropagation();
    if (!user) {
      navigate('/login');
      return;
    }

    const { data: existing } = await supabase
      .from('cart_items')
      .select('*')
      .eq('user_id', user.id)
      .eq('product_id', id)
      .maybeSingle();

    if (existing) {
      await supabase
        .from('cart_items')
        .update({ quantity: existing.quantity + quantity })
        .eq('id', existing.id);
    } else {
      await supabase
        .from('cart_items')
        .insert({
          user_id: user.id,
          product_id: id,
          quantity
        });
    }
  }

  async function toggleFavorite(e: React.MouseEvent) {
    e.stopPropagation();
    if (!user) {
      navigate('/login');
      return;
    }

    if (product?.is_favorite) {
      await supabase
        .from('favorites')
        .delete()
        .eq('user_id', user.id)
        .eq('product_id', id);
      setProduct(prev => prev ? { ...prev, is_favorite: false } : null);
    } else {
      await supabase
        .from('favorites')
        .insert({ user_id: user.id, product_id: id });
      setProduct(prev => prev ? { ...prev, is_favorite: true } : null);
    }
  }

  async function startChat() {
    if (!user) {
      navigate('/login');
      return;
    }

    const { data: existingRoom } = await supabase
      .from('chat_rooms')
      .select('id')
      .eq('product_id', id)
      .eq('buyer_id', user.id)
      .eq('seller_id', product?.seller_id)
      .maybeSingle();

    if (existingRoom) {
      navigate(`/chat/${existingRoom.id}`);
    } else {
      const { data: newRoom } = await supabase
        .from('chat_rooms')
        .insert({
          product_id: id,
          buyer_id: user.id,
          seller_id: product?.seller_id
        })
        .select()
        .single();
      if (newRoom) {
        navigate(`/chat/${newRoom.id}`);
      }
    }
  }

  async function submitReview(e: React.FormEvent) {
    e.preventDefault();
    if (!user || !id) return;

    setSubmitting(true);
    const { error } = await supabase
      .from('reviews')
      .insert({
        product_id: id,
        user_id: user.id,
        rating: reviewRating,
        comment: reviewComment
      });

    if (!error) {
      setShowReviewForm(false);
      setReviewRating(5);
      setReviewComment('');
      fetchReviews();
      fetchProduct();
    }
    setSubmitting(false);
  }

  if (loading) {
    return (
      <div className="py-12">
        <div className="container-custom">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            <div className="skeleton aspect-square rounded-2xl" />
            <div className="space-y-4">
              <div className="skeleton h-10 w-3/4" />
              <div className="skeleton h-6 w-1/2" />
              <div className="skeleton h-20 w-full" />
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="py-12 text-center">
        <Sparkles className="w-16 h-16 text-gray-600 mx-auto mb-4" />
        <p className="text-gray-400">Тауар табылмады</p>
        <Link to="/catalog" className="btn-secondary mt-4 inline-block">
          Каталогқа оралу
        </Link>
      </div>
    );
  }

  return (
    <div className="py-8 md:py-12">
      <div className="container-custom">
        {/* Breadcrumb */}
        <nav className="flex items-center gap-2 text-sm text-gray-400 mb-8">
          <Link to="/" className="hover:text-white transition-colors">Басты бет</Link>
          <span>/</span>
          <Link to="/catalog" className="hover:text-white transition-colors">Каталог</Link>
          {product.category && (
            <>
              <span>/</span>
              <Link
                to={`/catalog?category=${product.category.slug}`}
                className="hover:text-white transition-colors"
              >
                {product.category.name_kz}
              </Link>
            </>
          )}
        </nav>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12">
          {/* Images */}
          <div className="space-y-4">
            <div className="relative aspect-square rounded-2xl overflow-hidden glass-card">
              {product.images[currentImageIndex] ? (
                <motion.img
                  key={currentImageIndex}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  src={product.images[currentImageIndex]}
                  alt={product.title}
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center">
                  <Sparkles className="w-24 h-24 text-gray-600" />
                </div>
              )}

              {product.images.length > 1 && (
                <>
                  <button
                    onClick={() => setCurrentImageIndex((prev) => (prev - 1 + product.images.length) % product.images.length)}
                    className="absolute left-3 top-1/2 -translate-y-1/2 p-2 glass-button rounded-full"
                  >
                    <ChevronLeft className="w-5 h-5" />
                  </button>
                  <button
                    onClick={() => setCurrentImageIndex((prev) => (prev + 1) % product.images.length)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 p-2 glass-button rounded-full"
                  >
                    <ChevronRight className="w-5 h-5" />
                  </button>
                </>
              )}

              {product.compare_price > product.price && (
                <div className="absolute top-4 left-4 badge badge-danger text-base px-3 py-1">
                  -{Math.round((1 - product.price / product.compare_price) * 100)}%
                </div>
              )}
            </div>

            {/* Thumbnails */}
            {product.images.length > 1 && (
              <div className="flex gap-2 overflow-x-auto pb-2 no-scrollbar">
                {product.images.map((img, index) => (
                  <button
                    key={index}
                    onClick={() => setCurrentImageIndex(index)}
                    className={`w-20 h-20 rounded-lg overflow-hidden flex-shrink-0 transition-all ${
                      currentImageIndex === index
                        ? 'ring-2 ring-blue-500 opacity-100'
                        : 'opacity-60 hover:opacity-100'
                    }`}
                  >
                    <img src={img} alt="" className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Info */}
          <div className="space-y-6">
            <div>
              <h1 className="heading-lg mb-3">{product.title}</h1>
              <div className="flex items-center gap-4">
                <button className="flex items-center gap-1">
                  <Star className="w-5 h-5 text-yellow-400 fill-yellow-400" />
                  <span className="font-semibold">{product.rating.toFixed(1)}</span>
                  <span className="text-gray-400">({product.reviews_count} пікір)</span>
                </button>
                <span className="text-gray-600">|</span>
                <span className="text-gray-400">
                  {product.stock > 0 ? `${product.stock} қалды` : 'Жоқ'}
                </span>
              </div>
            </div>

            <div className="flex items-baseline gap-3">
              <span className="text-4xl font-bold text-gradient">
                {product.price.toLocaleString()} ₸
              </span>
              {product.compare_price > product.price && (
                <span className="text-xl text-gray-500 line-through">
                  {product.compare_price.toLocaleString()} ₸
                </span>
              )}
            </div>

            {/* Quantity */}
            <div className="flex items-center gap-4">
              <span className="text-gray-400">Мөлшері:</span>
              <div className="flex items-center gap-2 glass-light rounded-xl">
                <button
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="p-2 hover:bg-white/10 rounded-l-xl transition-colors"
                >
                  <Minus className="w-4 h-4" />
                </button>
                <span className="w-12 text-center font-semibold">{quantity}</span>
                <button
                  onClick={() => setQuantity(Math.min(product.stock, quantity + 1))}
                  className="p-2 hover:bg-white/10 rounded-r-xl transition-colors"
                >
                  <Plus className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Actions */}
            <div className="flex flex-col sm:flex-row gap-3">
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={addToCart}
                disabled={product.stock === 0}
                className="btn-primary flex-1 flex items-center justify-center gap-2"
              >
                <ShoppingCart className="w-5 h-5" />
                Себетке қосу
              </motion.button>
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={startChat}
                className="btn-secondary flex items-center justify-center gap-2"
              >
                <MessageCircle className="w-5 h-5" />
                Сатушымен чат
              </motion.button>
            </div>

            <div className="flex gap-2">
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={toggleFavorite}
                className="p-3 glass-button rounded-xl flex-1 flex items-center justify-center gap-2"
              >
                <Heart className={`w-5 h-5 ${product.is_favorite ? 'text-red-400 fill-red-400' : ''}`} />
                <span>{product.is_favorite ? 'Таңдаулы' : 'Таңдау'}</span>
              </motion.button>
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="p-3 glass-button rounded-xl flex-1 flex items-center justify-center gap-2"
              >
                <Share2 className="w-5 h-5" />
                <span>Бөлісу</span>
              </motion.button>
            </div>

            {/* Features */}
            <div className="grid grid-cols-3 gap-4">
              <div className="glass-card text-center py-4">
                <Truck className="w-6 h-6 text-blue-400 mx-auto mb-2" />
                <span className="text-sm text-gray-400">Жеткізу</span>
              </div>
              <div className="glass-card text-center py-4">
                <Shield className="w-6 h-6 text-emerald-400 mx-auto mb-2" />
                <span className="text-sm text-gray-400">Кепілдік</span>
              </div>
              <div className="glass-card text-center py-4">
                <Package className="w-6 h-6 text-amber-400 mx-auto mb-2" />
                <span className="text-sm text-gray-400">Қайтау</span>
              </div>
            </div>

            {/* Seller */}
            {product.seller && (
              <div className="glass-card p-4">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-blue-500 to-cyan-500 flex items-center justify-center text-lg font-bold">
                    {product.seller.full_name?.[0] || product.seller.email[0]}
                  </div>
                  <div className="flex-1">
                    <p className="font-medium">{product.seller.full_name || 'Сатушы'}</p>
                    <p className="text-sm text-gray-400">Сатушы</p>
                  </div>
                  <button
                    onClick={startChat}
                    className="btn-secondary text-sm"
                  >
                    Хабарласу
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Tabs */}
        <div className="mt-12">
          <div className="flex gap-2 mb-6">
            <button
              onClick={() => setActiveTab('description')}
              className={`px-6 py-3 rounded-xl font-medium transition-all ${
                activeTab === 'description'
                  ? 'bg-blue-500/20 text-blue-300'
                  : 'text-gray-400 hover:text-white hover:bg-white/5'
              }`}
            >
              Сипаттама
            </button>
            <button
              onClick={() => setActiveTab('reviews')}
              className={`px-6 py-3 rounded-xl font-medium transition-all ${
                activeTab === 'reviews'
                  ? 'bg-blue-500/20 text-blue-300'
                  : 'text-gray-400 hover:text-white hover:bg-white/5'
              }`}
            >
              Пікірлер ({reviews.length})
            </button>
          </div>

          <AnimatePresence mode="wait">
            {activeTab === 'description' ? (
              <motion.div
                key="description"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="glass-card"
              >
                <p className="text-gray-300 whitespace-pre-wrap">
                  {product.description || 'Сипаттама жоқ'}
                </p>
              </motion.div>
            ) : (
              <motion.div
                key="reviews"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="space-y-4"
              >
                {user && (
                  <button
                    onClick={() => setShowReviewForm(true)}
                    className="btn-primary"
                  >
                    Пікір қалдыру
                  </button>
                )}

                {/* Review Form */}
                <AnimatePresence>
                  {showReviewForm && (
                    <motion.form
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      exit={{ opacity: 0, height: 0 }}
                      onSubmit={submitReview}
                      className="glass-card"
                    >
                      <div className="mb-4">
                        <label className="block text-sm font-medium mb-2">Рейтинг</label>
                        <div className="flex gap-1">
                          {[1, 2, 3, 4, 5].map(star => (
                            <button
                              key={star}
                              type="button"
                              onClick={() => setReviewRating(star)}
                            >
                              <Star
                                className={`w-8 h-8 ${
                                  star <= reviewRating
                                    ? 'text-yellow-400 fill-yellow-400'
                                    : 'text-gray-600'
                                }`}
                              />
                            </button>
                          ))}
                        </div>
                      </div>
                      <div className="mb-4">
                        <label className="block text-sm font-medium mb-2">Пікір</label>
                        <textarea
                          value={reviewComment}
                          onChange={(e) => setReviewComment(e.target.value)}
                          rows={4}
                          className="glass-input resize-none"
                          placeholder="Тауар туралы пікіріңізді жазыңыз..."
                        />
                      </div>
                      <div className="flex gap-2">
                        <button
                          type="submit"
                          disabled={submitting}
                          className="btn-primary"
                        >
                          {submitting ? 'Жіберілуде...' : 'Жіберу'}
                        </button>
                        <button
                          type="button"
                          onClick={() => setShowReviewForm(false)}
                          className="btn-secondary"
                        >
                          Бас тарту
                        </button>
                      </div>
                    </motion.form>
                  )}
                </AnimatePresence>

                {/* Reviews List */}
                {reviews.length === 0 ? (
                  <div className="glass-card text-center py-8">
                    <p className="text-gray-400">Пікірлер жоқ</p>
                  </div>
                ) : (
                  reviews.map(review => (
                    <div key={review.id} className="glass-card">
                      <div className="flex items-start gap-3">
                        <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-500 to-cyan-500 flex items-center justify-center font-bold flex-shrink-0">
                          {review.user.full_name?.[0] || review.user.email[0]}
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center justify-between mb-2">
                            <div>
                              <p className="font-medium">{review.user.full_name || 'Қолданушы'}</p>
                              <div className="flex items-center gap-1">
                                {[...Array(5)].map((_, i) => (
                                  <Star
                                    key={i}
                                    className={`w-4 h-4 ${
                                      i < review.rating
                                        ? 'text-yellow-400 fill-yellow-400'
                                        : 'text-gray-600'
                                    }`}
                                  />
                                ))}
                              </div>
                            </div>
                            <span className="text-sm text-gray-500">
                              {new Date(review.created_at).toLocaleDateString('kk-KZ')}
                            </span>
                          </div>
                          <p className="text-gray-300">{review.comment}</p>
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}
