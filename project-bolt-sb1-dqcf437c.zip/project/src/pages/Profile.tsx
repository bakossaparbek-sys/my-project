import { useState } from 'react';
import { motion } from 'framer-motion';
import { User, Mail, Camera, Save, Shield, ShoppingBag, Store, Edit2 } from 'lucide-react';
import { useAuth } from '../lib/auth-context';
import { supabase } from '../lib/supabase';

export default function Profile() {
  const { user, profile, updateProfile } = useAuth();
  const [fullName, setFullName] = useState(profile?.full_name || '');
  const [editingName, setEditingName] = useState(false);
  const [saving, setSaving] = useState(false);
  const [success, setSuccess] = useState(false);

  async function handleSave() {
    if (!fullName.trim()) return;
    setSaving(true);
    await updateProfile({ full_name: fullName });
    setEditingName(false);
    setSaving(false);
    setSuccess(true);
    setTimeout(() => setSuccess(false), 3000);
  }

  return (
    <div className="py-8 md:py-12">
      <div className="container-custom">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-2xl mx-auto"
        >
          <h1 className="heading-lg mb-8">Профиль</h1>

          {/* Profile Card */}
          <div className="glass-card mb-6">
            <div className="flex flex-col sm:flex-row items-center gap-6">
              <div className="relative group">
                <div className="w-24 h-24 rounded-2xl bg-gradient-to-br from-blue-500 to-cyan-500 flex items-center justify-center text-4xl font-bold">
                  {profile?.full_name?.[0] || profile?.email?.[0] || 'U'}
                </div>
                <button className="absolute inset-0 rounded-2xl bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                  <Camera className="w-6 h-6" />
                </button>
              </div>

              <div className="flex-1 text-center sm:text-left">
                {editingName ? (
                  <div className="flex gap-2 mb-2">
                    <input
                      type="text"
                      value={fullName}
                      onChange={(e) => setFullName(e.target.value)}
                      className="glass-input flex-1"
                      autoFocus
                    />
                    <button
                      onClick={handleSave}
                      disabled={saving}
                      className="btn-primary"
                    >
                      <Save className="w-4 h-4" />
                    </button>
                  </div>
                ) : (
                  <div className="flex items-center justify-center sm:justify-start gap-2 mb-2">
                    <h2 className="text-2xl font-bold">{profile?.full_name || 'Қолданушы'}</h2>
                    <button
                      onClick={() => setEditingName(true)}
                      className="p-1 hover:bg-white/10 rounded transition-colors"
                    >
                      <Edit2 className="w-4 h-4" />
                    </button>
                  </div>
                )}

                <div className="flex items-center justify-center sm:justify-start gap-2 text-gray-400">
                  <Mail className="w-4 h-4" />
                  <span>{profile?.email}</span>
                </div>

                <div className="flex items-center justify-center sm:justify-start gap-2 mt-2">
                  <span className={`badge ${
                    profile?.role === 'admin' ? 'badge-danger' :
                    profile?.role === 'seller' ? 'badge-warning' : 'badge-primary'
                  }`}>
                    {profile?.role === 'admin' ? 'Әкімші' :
                     profile?.role === 'seller' ? 'Сатушы' : 'Сатып алушы'}
                  </span>
                </div>
              </div>
            </div>

            {success && (
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                className="mt-4 text-center text-emerald-400 text-sm"
              >
                Профиль сәтті жаңартылды
              </motion.div>
            )}
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-6">
            <div className="glass-card text-center">
              <ShoppingBag className="w-6 h-6 text-blue-400 mx-auto mb-2" />
              <p className="text-2xl font-bold">0</p>
              <p className="text-sm text-gray-400">Тапсырыстар</p>
            </div>
            <div className="glass-card text-center">
              <svg className="w-6 h-6 text-red-400 mx-auto mb-2" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M3.172 5.172a4 4 0 015.656 0L10 6.343l1.172-1.171a4 4 0 115.656 5.656L10 17.657l-6.828-6.828a4 4 0 010-5.656z" clipRule="evenodd" />
              </svg>
              <p className="text-2xl font-bold">0</p>
              <p className="text-sm text-gray-400">Таңдаулы</p>
            </div>
            <div className="glass-card text-center">
              <Store className="w-6 h-6 text-amber-400 mx-auto mb-2" />
              <p className="text-2xl font-bold">0</p>
              <p className="text-sm text-gray-400">Тауарлар</p>
            </div>
            <div className="glass-card text-center">
              <Shield className="w-6 h-6 text-emerald-400 mx-auto mb-2" />
              <p className="text-sm text-gray-400">Қауіпсіз</p>
            </div>
          </div>

          {/* Actions */}
          <div className="space-y-4">
            {(profile?.role === 'seller' || profile?.role === 'admin') && (
              <motion.a
                whileHover={{ scale: 1.01 }}
                href="/admin"
                className="glass-card flex items-center gap-4 cursor-pointer hover:border-blue-500/30"
              >
                <div className="w-12 h-12 rounded-xl bg-blue-500/20 flex items-center justify-center">
                  <Store className="w-6 h-6 text-blue-400" />
                </div>
                <div className="flex-1">
                  <p className="font-medium">Сатушы панелі</p>
                  <p className="text-sm text-gray-400">Тауарларыңызды басқарыңыз</p>
                </div>
              </motion.a>
            )}

            <motion.a
              whileHover={{ scale: 1.01 }}
              href="/orders"
              className="glass-card flex items-center gap-4 cursor-pointer hover:border-blue-500/30"
            >
              <div className="w-12 h-12 rounded-xl bg-amber-500/20 flex items-center justify-center">
                <ShoppingBag className="w-6 h-6 text-amber-400" />
              </div>
              <div className="flex-1">
                <p className="font-medium">Тапсырыстар</p>
                <p className="text-sm text-gray-400">Тапсырыстар тарихын көріңіз</p>
              </div>
            </motion.a>
          </div>

          {/* Security Info */}
          <div className="mt-8 glass-light rounded-xl p-4 flex items-start gap-3">
            <Shield className="w-5 h-5 text-emerald-400 flex-shrink-0 mt-0.5" />
            <div>
              <p className="font-medium mb-1">Қауіпсіздік</p>
              <p className="text-sm text-gray-400">
                Барлық деректеріңіз шифрланған және қорғалған. Есептік жазбаңызды бөліспеңіз.
              </p>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
