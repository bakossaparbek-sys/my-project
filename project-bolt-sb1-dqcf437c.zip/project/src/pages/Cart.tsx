import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  ShoppingCart,
  Trash2,
  Minus,
  Plus,
  AlertCircle,
  CreditCard,
  MapPin,
  Phone,
  User
} from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../lib/auth-context';
import type { CartItemWithProduct } from '../types/database';

export default function Cart() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [cartItems, setCartItems] = useState<CartItemWithProduct[]>([]);
  const [loading, setLoading] = useState(true);
  const [checkout, setCheckout] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [shippingAddress, setShippingAddress] = useState({
    full_name: '',
    phone: '',
    city: '',
    address: '',
    postal_code: ''
  });

  useEffect(() => {
    if (user) {
      fetchCartItems();
    } else {
      setLoading(false);
    }
  }, [user]);

  async function fetchCartItems() {
    const { data } = await supabase
      .from('cart_items')
      .select(`
        *,
        product:products(
          *,
          category:categories(*),
          seller:profiles(*)
        )
      `)
      .eq('user_id', user!.id);

    if (data) {
      setCartItems(data as CartItemWithProduct[]);
    }
    setLoading(false);
  }

  async function updateQuantity(id: string, newQuantity: number) {
    if (newQuantity < 1) return;
    await supabase
      .from('cart_items')
      .update({ quantity: newQuantity })
      .eq('id', id);
    fetchCartItems();
  }

  async function removeItem(id: string) {
    await supabase
      .from('cart_items')
      .delete()
      .eq('id', id);
    setCartItems(prev => prev.filter(item => item.id !== id));
  }

  async function clearCart() {
    await supabase
      .from('cart_items')
      .delete()
      .eq('user_id', user!.id);
    setCartItems([]);
  }

  const subtotal = cartItems.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  const shipping = subtotal > 50000 ? 0 : 2000;
  const total = subtotal + shipping;

  async function handleCheckout(e: React.FormEvent) {
    e.preventDefault();
    if (!user || cartItems.length === 0) return;

    setSubmitting(true);

    // Create order
    const { data: order, error: orderError } = await supabase
      .from('orders')
      .insert({
        user_id: user.id,
        total,
        shipping_address: shippingAddress,
        status: 'pending',
        payment_status: 'pending'
      })
      .select()
      .single();

    if (orderError || !order) {
      setSubmitting(false);
      return;
    }

    // Create order items
    const orderItems = cartItems.map(item => ({
      order_id: order.id,
      product_id: item.product_id,
      quantity: item.quantity,
      price: item.product.price
    }));

    await supabase
      .from('order_items')
      .insert(orderItems);

    // Clear cart
    await clearCart();

    setSubmitting(false);
    navigate('/orders');
  }

  if (!user) {
    return (
      <div className="py-12 text-center">
        <ShoppingCart className="w-16 h-16 text-gray-600 mx-auto mb-4" />
        <h2 className="text-xl font-semibold mb-2">Себет бос</h2>
        <p className="text-gray-400 mb-6">Себетіңізді толтыру үшін кініңіз</p>
        <Link to="/login">
          <button className="btn-primary">Кіру</button>
        </Link>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="py-12">
        <div className="container-custom">
          <div className="skeleton h-8 w-32 mb-8" />
          <div className="space-y-4">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="glass-card">
                <div className="flex gap-4">
                  <div className="skeleton w-24 h-24 rounded-xl" />
                  <div className="flex-1">
                    <div className="skeleton h-4 w-3/4 mb-2" />
                    <div className="skeleton h-4 w-1/2" />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (cartItems.length === 0) {
    return (
      <div className="py-12 text-center">
        <ShoppingCart className="w-16 h-16 text-gray-600 mx-auto mb-4" />
        <h2 className="text-xl font-semibold mb-2">Себет бос</h2>
        <p className="text-gray-400 mb-6">Себетіңізге тауар қосыңыз</p>
        <Link to="/catalog">
          <button className="btn-primary">Каталогқа өту</button>
        </Link>
      </div>
    );
  }

  return (
    <div className="py-8 md:py-12">
      <div className="container-custom">
        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="heading-lg mb-8"
        >
          Себет ({cartItems.length})
        </motion.h1>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Cart Items */}
          <div className="lg:col-span-2 space-y-4">
            <AnimatePresence>
              {cartItems.map((item) => (
                <motion.div
                  key={item.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, x: -100 }}
                  className="glass-card"
                >
                  <div className="flex gap-4">
                    <Link to={`/product/${item.product.id}`} className="flex-shrink-0">
                      <div className="w-24 h-24 rounded-xl overflow-hidden bg-slate-800">
                        {item.product.images[0] ? (
                          <img
                            src={item.product.images[0]}
                            alt={item.product.title}
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center">
                            <ShoppingCart className="w-8 h-8 text-gray-600" />
                          </div>
                        )}
                      </div>
                    </Link>
                    <div className="flex-1 min-w-0">
                      <Link
                        to={`/product/${item.product.id}`}
                        className="font-medium hover:text-blue-400 transition-colors line-clamp-2"
                      >
                        {item.product.title}
                      </Link>
                      <p className="text-lg font-bold text-gradient mt-1">
                        {item.product.price.toLocaleString()} ₸
                      </p>
                      <div className="flex items-center justify-between mt-3">
                        <div className="flex items-center gap-2 glass-light rounded-lg">
                          <button
                            onClick={() => updateQuantity(item.id, item.quantity - 1)}
                            className="p-1.5 hover:bg-white/10 rounded-l-lg transition-colors"
                          >
                            <Minus className="w-4 h-4" />
                          </button>
                          <span className="w-10 text-center font-medium">{item.quantity}</span>
                          <button
                            onClick={() => updateQuantity(item.id, item.quantity + 1)}
                            className="p-1.5 hover:bg-white/10 rounded-r-lg transition-colors"
                          >
                            <Plus className="w-4 h-4" />
                          </button>
                        </div>
                        <button
                          onClick={() => removeItem(item.id)}
                          className="p-2 text-red-400 hover:bg-red-500/10 rounded-lg transition-colors"
                        >
                          <Trash2 className="w-5 h-5" />
                        </button>
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>

            <button
              onClick={clearCart}
              className="text-red-400 hover:text-red-300 transition-colors flex items-center gap-2"
            >
              <Trash2 className="w-4 h-4" />
              Себетті тазалау
            </button>
          </div>

          {/* Order Summary */}
          <div className="lg:col-span-1">
            <div className="glass-card sticky top-24">
              <h3 className="text-xl font-semibold mb-6">Тапсырыс қорытындысы</h3>

              <div className="space-y-3 mb-6">
                <div className="flex justify-between">
                  <span className="text-gray-400">Тауарлар ({cartItems.length})</span>
                  <span>{subtotal.toLocaleString()} ₸</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Жеткізу</span>
                  <span>{shipping === 0 ? 'Тегін' : `${shipping} ₸`}</span>
                </div>
                {shipping === 0 && (
                  <p className="text-sm text-emerald-400">
                    50 000 ₸-тан жоғары тапсырыстарға тегін жеткізу!
                  </p>
                )}
                {shipping > 0 && subtotal > 30000 && (
                  <p className="text-sm text-amber-400">
                    {`Тағы ${(50000 - subtotal).toLocaleString()} ₸-ға сатып алыңыз және тегін жеткізуден бас тартыңыз`}
                  </p>
                )}
                <div className="divider" />
                <div className="flex justify-between text-lg font-semibold">
                  <span>Барлығы</span>
                  <span className="text-gradient">{total.toLocaleString()} ₸</span>
                </div>
              </div>

              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => setCheckout(true)}
                className="btn-primary w-full flex items-center justify-center gap-2"
              >
                <CreditCard className="w-5 h-5" />
                Тапсырыс беру
              </motion.button>

              <p className="text-xs text-gray-500 text-center mt-4">
                Тапсырыс беру арқылы сіз шарттарымызбен келісесіз
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Checkout Modal */}
      <AnimatePresence>
        {checkout && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4"
            onClick={() => setCheckout(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="glass-card max-w-lg w-full max-h-[90vh] overflow-y-auto"
            >
              <h3 className="text-2xl font-semibold mb-6">Жеткізу мекенжайы</h3>

              <form onSubmit={handleCheckout} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-2">Аты-жөні *</label>
                  <div className="relative">
                    <User className="input-icon-left w-5 h-5" />
                    <input
                      type="text"
                      value={shippingAddress.full_name}
                      onChange={(e) => setShippingAddress(prev => ({ ...prev, full_name: e.target.value }))}
                      required
                      className="glass-input pl-10"
                      placeholder="Аты-жөніңіз"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">Телефон *</label>
                  <div className="relative">
                    <Phone className="input-icon-left w-5 h-5" />
                    <input
                      type="tel"
                      value={shippingAddress.phone}
                      onChange={(e) => setShippingAddress(prev => ({ ...prev, phone: e.target.value }))}
                      required
                      className="glass-input pl-10"
                      placeholder="+7 777 123 45 67"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">Қала *</label>
                  <div className="relative">
                    <MapPin className="input-icon-left w-5 h-5" />
                    <input
                      type="text"
                      value={shippingAddress.city}
                      onChange={(e) => setShippingAddress(prev => ({ ...prev, city: e.target.value }))}
                      required
                      className="glass-input pl-10"
                      placeholder="Алматы"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">Мекенжай *</label>
                  <input
                    type="text"
                    value={shippingAddress.address}
                    onChange={(e) => setShippingAddress(prev => ({ ...prev, address: e.target.value }))}
                    required
                    className="glass-input"
                    placeholder="Көше, үй, пәтер"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">Индекс</label>
                  <input
                    type="text"
                    value={shippingAddress.postal_code}
                    onChange={(e) => setShippingAddress(prev => ({ ...prev, postal_code: e.target.value }))}
                    className="glass-input"
                    placeholder="050000"
                  />
                </div>

                <div className="glass-light rounded-xl p-4">
                  <div className="flex justify-between mb-2">
                    <span className="text-gray-400">Тауарлар</span>
                    <span>{subtotal.toLocaleString()} ₸</span>
                  </div>
                  <div className="flex justify-between mb-2">
                    <span className="text-gray-400">Жеткізу</span>
                    <span>{shipping === 0 ? 'Тегін' : `${shipping} ₸`}</span>
                  </div>
                  <div className="divider" />
                  <div className="flex justify-between font-semibold">
                    <span>Барлығы</span>
                    <span className="text-gradient">{total.toLocaleString()} ₸</span>
                  </div>
                </div>

                <div className="flex gap-3">
                  <button
                    type="button"
                    onClick={() => setCheckout(false)}
                    className="btn-secondary flex-1"
                  >
                    Бас тарту
                  </button>
                  <button
                    type="submit"
                    disabled={submitting}
                    className="btn-primary flex-1"
                  >
                    {submitting ? 'Өңделуде...' : 'Растау'}
                  </button>
                </div>
              </form>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
