import { useState, useEffect, useRef } from 'react';
import { useParams, Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { MessageCircle, Send, ArrowLeft, User, Package } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../lib/auth-context';
import type { ChatRoomWithDetails, ChatMessage, Product, Profile } from '../types/database';

export default function Chat() {
  const { roomId } = useParams();
  const { user, profile } = useAuth();
  const [rooms, setRooms] = useState<ChatRoomWithDetails[]>([]);
  const [currentRoom, setCurrentRoom] = useState<ChatRoomWithDetails | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [loading, setLoading] = useState(true);
  const [mobileShowChat, setMobileShowChat] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (user) {
      fetchRooms();
    } else {
      setLoading(false);
    }
  }, [user]);

  useEffect(() => {
    if (roomId && rooms.length > 0) {
      const room = rooms.find(r => r.id === roomId);
      if (room) {
        setCurrentRoom(room);
        fetchMessages(roomId);
        markAsRead(roomId);
      }
    }
  }, [roomId, rooms]);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  useEffect(() => {
    if (!user) return;

    // Subscribe to new messages
    const channel = supabase
      .channel('chat_messages')
      .on('postgres_changes', {
        event: 'INSERT',
        schema: 'public',
        table: 'chat_messages'
      }, (payload) => {
        const newMsg = payload.new as ChatMessage;
        if (newMsg.room_id === currentRoom?.id) {
          setMessages(prev => [...prev, newMsg]);
          if (newMsg.sender_id !== user.id) {
            markAsRead(currentRoom.id);
          }
        }
      })
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user, currentRoom]);

  async function fetchRooms() {
    const { data } = await supabase
      .from('chat_rooms')
      .select(`
        *,
        product:products(*),
        buyer:profiles!chat_rooms_buyer_id_fkey(*),
        seller:profiles!chat_rooms_seller_id_fkey(*)
      `)
      .or(`buyer_id.eq.${user!.id},seller_id.eq.${user!.id}`)
      .order('updated_at', { ascending: false });

    if (data) {
      const roomsData = data as ChatRoomWithDetails[];

      // Get last message and unread count for each room
      for (const room of roomsData) {
        const { data: lastMsg } = await supabase
          .from('chat_messages')
          .select('*')
          .eq('room_id', room.id)
          .order('created_at', { ascending: false })
          .limit(1)
          .maybeSingle();

        const { count } = await supabase
          .from('chat_messages')
          .select('*', { count: 'exact', head: true })
          .eq('room_id', room.id)
          .eq('read_at', null)
          .neq('sender_id', user!.id);

        room.last_message = lastMsg || undefined;
        room.unread_count = count || 0;
      }

      setRooms(roomsData);
    }
    setLoading(false);
  }

  async function fetchMessages(roomId: string) {
    const { data } = await supabase
      .from('chat_messages')
      .select('*')
      .eq('room_id', roomId)
      .order('created_at', { ascending: true });

    if (data) {
      setMessages(data);
    }
  }

  async function markAsRead(roomId: string) {
    await supabase
      .from('chat_messages')
      .update({ read_at: new Date().toISOString() })
      .eq('room_id', roomId)
      .eq('read_at', null)
      .neq('sender_id', user!.id);
  }

  async function sendMessage(e: React.FormEvent) {
    e.preventDefault();
    if (!newMessage.trim() || !currentRoom || !user) return;

    const { data, error } = await supabase
      .from('chat_messages')
      .insert({
        room_id: currentRoom.id,
        sender_id: user.id,
        message: newMessage.trim()
      })
      .select()
      .single();

    if (data && !error) {
      setMessages(prev => [...prev, data]);
      setNewMessage('');
      fetchRooms();
    }
  }

  function scrollToBottom() {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }

  function getOtherUser(room: ChatRoomWithDetails): Profile | undefined {
    return room.buyer_id === user?.id ? room.seller : room.buyer;
  }

  function formatMessageTime(dateString: string) {
    const date = new Date(dateString);
    const now = new Date();
    const diffDays = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60 * 24));

    if (diffDays === 0) {
      return date.toLocaleTimeString('kk-KZ', { hour: '2-digit', minute: '2-digit' });
    } else if (diffDays === 1) {
      return 'Кеше';
    } else if (diffDays < 7) {
      return date.toLocaleDateString('kk-KZ', { weekday: 'long' });
    } else {
      return date.toLocaleDateString('kk-KZ');
    }
  }

  if (!user) {
    return (
      <div className="py-12 text-center">
        <MessageCircle className="w-16 h-16 text-gray-600 mx-auto mb-4" />
        <h2 className="text-xl font-semibold mb-2">Кіру қажет</h2>
        <p className="text-gray-400 mb-6">Чатты пайдалану үшін жүйеге кіріңіз</p>
        <Link to="/login">
          <button className="btn-primary">Кіру</button>
        </Link>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="py-12">
        <div className="container-custom">
          <div className="skeleton h-8 w-24 mb-8" />
          <div className="glass-card h-96">
            <div className="skeleton w-64 h-full" />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="py-8 md:py-12">
      <div className="container-custom">
        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="heading-lg mb-8"
        >
          Хабарлар
        </motion.h1>

        {rooms.length === 0 ? (
          <div className="text-center py-12">
            <MessageCircle className="w-16 h-16 text-gray-600 mx-auto mb-4" />
            <h2 className="text-xl font-semibold mb-2">Хабарлар жоқ</h2>
            <p className="text-gray-400 mb-6">Сатушылармен хабарласқанда пайда болады</p>
            <Link to="/catalog">
              <button className="btn-primary">Каталогқа өту</button>
            </Link>
          </div>
        ) : (
          <div className="glass rounded-2xl overflow-hidden flex h-[600px]">
            {/* Rooms List */}
            <div className={`w-full md:w-80 flex-shrink-0 border-r border-white/10 ${mobileShowChat ? 'hidden md:block' : ''}`}>
              <div className="h-full overflow-y-auto scrollbar-thin">
                {rooms.map(room => {
                  const otherUser = getOtherUser(room);
                  return (
                    <button
                      key={room.id}
                      onClick={() => {
                        setCurrentRoom(room);
                        fetchMessages(room.id);
                        markAsRead(room.id);
                        setMobileShowChat(true);
                      }}
                      className={`w-full p-4 flex gap-3 border-b border-white/5 hover:bg-white/5 transition-colors ${
                        currentRoom?.id === room.id ? 'bg-blue-500/10' : ''
                      }`}
                    >
                      <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-blue-500 to-cyan-500 flex items-center justify-center flex-shrink-0">
                        {otherUser?.full_name?.[0] || otherUser?.email[0] || 'U'}
                      </div>
                      <div className="flex-1 min-w-0 text-left">
                        <div className="flex items-center justify-between mb-1">
                          <p className="font-medium truncate">
                            {otherUser?.full_name || 'Қолданушы'}
                          </p>
                          {room.unread_count > 0 && (
                            <span className="w-5 h-5 bg-blue-500 rounded-full text-xs font-bold flex items-center justify-center">
                              {room.unread_count}
                            </span>
                          )}
                        </div>
                        <p className="text-sm text-gray-400 truncate">{room.product?.title}</p>
                        {room.last_message && (
                          <p className="text-xs text-gray-500 truncate mt-1">
                            {room.last_message.sender_id === user.id ? 'Сіз: ' : ''}
                            {room.last_message.message}
                          </p>
                        )}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Chat Area */}
            <div className={`flex-1 flex flex-col ${mobileShowChat ? '' : 'hidden md:flex'}`}>
              {currentRoom ? (
                <>
                  {/* Chat Header */}
                  <div className="p-4 border-b border-white/10 flex items-center gap-3">
                    <button
                      onClick={() => setMobileShowChat(false)}
                      className="md:hidden p-2 glass-button rounded-xl"
                    >
                      <ArrowLeft className="w-5 h-5" />
                    </button>
                    <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-500 to-cyan-500 flex items-center justify-center">
                      {getOtherUser(currentRoom)?.full_name?.[0] || 'U'}
                    </div>
                    <div className="flex-1">
                      <p className="font-medium">
                        {getOtherUser(currentRoom)?.full_name || 'Қолданушы'}
                      </p>
                      <p className="text-sm text-gray-400">
                        {currentRoom.buyer_id === user?.id ? 'Сатушы' : 'Сатып алушы'}
                      </p>
                    </div>
                    {currentRoom.product && (
                      <Link
                        to={`/product/${currentRoom.product.id}`}
                        className="flex items-center gap-2 glass-light rounded-xl px-3 py-2"
                      >
                        <Package className="w-4 h-4" />
                        <span className="text-sm">{currentRoom.product.title.substring(0, 20)}...</span>
                      </Link>
                    )}
                  </div>

                  {/* Messages */}
                  <div className="flex-1 overflow-y-auto p-4 space-y-3 scrollbar-thin">
                    {messages.map(message => (
                      <motion.div
                        key={message.id}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        className={`flex ${message.sender_id === user?.id ? 'justify-end' : 'justify-start'}`}
                      >
                        <div
                          className={`max-w-[70%] rounded-2xl px-4 py-2 ${
                            message.sender_id === user?.id
                              ? 'bg-blue-500/20 border border-blue-500/30'
                              : 'glass-light'
                          }`}
                        >
                          <p>{message.message}</p>
                          <p className="text-xs text-gray-500 mt-1">
                            {formatMessageTime(message.created_at)}
                          </p>
                        </div>
                      </motion.div>
                    ))}
                    <div ref={messagesEndRef} />
                  </div>

                  {/* Message Input */}
                  <form
                    onSubmit={sendMessage}
                    className="p-4 border-t border-white/10 flex gap-2"
                  >
                    <input
                      type="text"
                      value={newMessage}
                      onChange={(e) => setNewMessage(e.target.value)}
                      placeholder="Хабарды жазыңыз..."
                      className="glass-input flex-1"
                    />
                    <motion.button
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      type="submit"
                      disabled={!newMessage.trim()}
                      className="btn-primary px-4 disabled:opacity-50"
                    >
                      <Send className="w-5 h-5" />
                    </motion.button>
                  </form>
                </>
              ) : (
                <div className="flex-1 flex items-center justify-center text-gray-400">
                  <p>Чатты таңдаңыз</p>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
