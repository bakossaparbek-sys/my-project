import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Package, Eye, X, ShoppingBag, Calendar, MapPin } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../lib/auth-context';
import type { Order, OrderItem, Product } from '../types/database';

interface OrderWithItems extends Order {
  items: (OrderItem & { product: Product | null })[];
}

const statusLabels: Record<string, string> = {
  pending: 'Күтуде',
  processing: 'Өңделуде',
  shipped: 'Жолда',
  delivered: 'Жеткізілді',
  cancelled: 'Бас тартылды'
};

const statusColors: Record<string, string> = {
  pending: 'badge-warning',
  processing: 'badge-primary',
  shipped: 'badge-primary',
  delivered: 'badge-success',
  cancelled: 'badge-danger'
};

export default function Orders() {
  const { user } = useAuth();
  const [orders, setOrders] = useState<OrderWithItems[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedOrder, setSelectedOrder] = useState<OrderWithItems | null>(null);

  useEffect(() => {
    if (user) {
      fetchOrders();
    } else {
      setLoading(false);
    }
  }, [user]);

  async function fetchOrders() {
    const { data } = await supabase
      .from('orders')
      .select('*')
      .eq('user_id', user!.id)
      .order('created_at', { ascending: false });

    if (data) {
      const ordersWithItems = await Promise.all(
        data.map(async (order) => {
          const { data: items } = await supabase
            .from('order_items')
            .select(`
              *,
              product:products(*)
            `)
            .eq('order_id', order.id);
          return { ...order, items: items || [] };
        })
      );
      setOrders(ordersWithItems as OrderWithItems[]);
    }
    setLoading(false);
  }

  if (!user) {
    return (
      <div className="py-12 text-center">
        <Package className="w-16 h-16 text-gray-600 mx-auto mb-4" />
        <h2 className="text-xl font-semibold mb-2">Кіру қажет</h2>
        <p className="text-gray-400 mb-6">Тапсырыстарыңызды көру үшін жүйеге кіріңіз</p>
        <Link to="/login">
          <button className="btn-primary">Кіру</button>
        </Link>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="py-12">
        <div className="container-custom">
          <div className="skeleton h-8 w-40 mb-8" />
          <div className="space-y-4">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="glass-card">
                <div className="skeleton h-24 w-full" />
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="py-8 md:py-12">
      <div className="container-custom">
        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="heading-lg mb-8"
        >
          Тапсырыстар ({orders.length})
        </motion.h1>

        {orders.length === 0 ? (
          <div className="text-center py-12">
            <ShoppingBag className="w-16 h-16 text-gray-600 mx-auto mb-4" />
            <h2 className="text-xl font-semibold mb-2">Тапсырыстар жоқ</h2>
            <p className="text-gray-400 mb-6">Алғашқы тапсырысыңызді жасаңыз</p>
            <Link to="/catalog">
              <button className="btn-primary">Каталогқа өту</button>
            </Link>
          </div>
        ) : (
          <div className="space-y-4">
            {orders.map((order, index) => (
              <motion.div
                key={order.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
                className="glass-card"
              >
                <div className="flex flex-col md:flex-row md:items-center gap-4">
                  <div className="flex items-center gap-4 flex-1">
                    <div className="w-16 h-16 rounded-xl bg-gradient-to-br from-blue-500/20 to-cyan-500/20 flex items-center justify-center">
                      <Package className="w-8 h-8 text-blue-400" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-semibold">
                          Тапсырыс #{order.id.substring(0, 8)}
                        </span>
                        <span className={`badge ${statusColors[order.status]}`}>
                          {statusLabels[order.status]}
                        </span>
                      </div>
                      <div className="flex items-center gap-4 text-sm text-gray-400">
                        <span className="flex items-center gap-1">
                          <Calendar className="w-4 h-4" />
                          {new Date(order.created_at).toLocaleDateString('kk-KZ')}
                        </span>
                        <span>
                          {order.items.length} тауар
                        </span>
                        <span className="font-semibold text-gradient">
                          {order.total.toLocaleString()} ₸
                        </span>
                      </div>
                    </div>
                  </div>
                  <button
                    onClick={() => setSelectedOrder(order)}
                    className="btn-secondary flex items-center justify-center gap-2"
                  >
                    <Eye className="w-4 h-4" />
                    Толығырақ
                  </button>
                </div>
              </motion.div>
            ))}
          </div>
        )}

        {/* Order Details Modal */}
        {selectedOrder && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4"
            onClick={() => setSelectedOrder(null)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="glass-card max-w-2xl w-full max-h-[90vh] overflow-y-auto"
            >
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-semibold">
                  Тапсырыс #{selectedOrder.id.substring(0, 8)}
                </h3>
                <button
                  onClick={() => setSelectedOrder(null)}
                  className="p-2 hover:bg-white/10 rounded-lg transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="space-y-6">
                <div className="flex items-center gap-2">
                  <span className={`badge ${statusColors[selectedOrder.status]}`}>
                    {statusLabels[selectedOrder.status]}
                  </span>
                  <span className="text-sm text-gray-400">
                    {new Date(selectedOrder.created_at).toLocaleDateString('kk-KZ', {
                      year: 'numeric',
                      month: 'long',
                      day: 'numeric',
                      hour: '2-digit',
                      minute: '2-digit'
                    })}
                  </span>
                </div>

                {/* Shipping Address */}
                {selectedOrder.shipping_address && (
                  <div className="glass-light rounded-xl p-4">
                    <h4 className="font-medium mb-2 flex items-center gap-2">
                      <MapPin className="w-4 h-4 text-blue-400" />
                      Жеткізу мекенжайы
                    </h4>
                    <p className="text-gray-300">
                      {(selectedOrder.shipping_address as any).full_name}
                    </p>
                    <p className="text-gray-400">
                      {(selectedOrder.shipping_address as any).phone}
                    </p>
                    <p className="text-gray-400">
                      {(selectedOrder.shipping_address as any).city}, {(selectedOrder.shipping_address as any).address}
                    </p>
                  </div>
                )}

                {/* Order Items */}
                <div>
                  <h4 className="font-medium mb-3">Тауарлар</h4>
                  <div className="space-y-3">
                    {selectedOrder.items.map((item) => (
                      <div
                        key={item.id}
                        className="flex gap-3 glass-light rounded-xl p-3"
                      >
                        <div className="w-16 h-16 rounded-lg bg-slate-800 flex-shrink-0 overflow-hidden">
                          {item.product?.images?.[0] ? (
                            <img
                              src={item.product.images[0]}
                              alt={item.product.title}
                              className="w-full h-full object-cover"
                            />
                          ) : (
                            <div className="w-full h-full flex items-center justify-center">
                              <Package className="w-6 h-6 text-gray-600" />
                            </div>
                          )}
                        </div>
                        <div className="flex-1 min-w-0">
                          {item.product ? (
                            <Link
                              to={`/product/${item.product.id}`}
                              className="font-medium hover:text-blue-400 transition-colors line-clamp-1"
                            >
                              {item.product.title}
                            </Link>
                          ) : (
                            <p className="text-gray-400">Тауар жойылған</p>
                          )}
                          <p className="text-sm text-gray-400">
                            {item.quantity} x {item.price.toLocaleString()} ₸
                          </p>
                        </div>
                        <span className="font-semibold">
                          {(item.quantity * item.price).toLocaleString()} ₸
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Summary */}
                <div className="glass-light rounded-xl p-4">
                  <div className="flex justify-between mb-2">
                    <span className="text-gray-400">Тауарлар</span>
                    <span>
                      {selectedOrder.items.reduce((sum, item) => sum + item.price * item.quantity, 0).toLocaleString()} ₸
                    </span>
                  </div>
                  <div className="divider" />
                  <div className="flex justify-between text-lg font-semibold">
                    <span>Барлығы</span>
                    <span className="text-gradient">{selectedOrder.total.toLocaleString()} ₸</span>
                  </div>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </div>
    </div>
  );
}
