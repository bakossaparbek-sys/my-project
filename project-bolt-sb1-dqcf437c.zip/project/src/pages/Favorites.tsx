import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Heart, Star, Trash2, ShoppingCart, Sparkles } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../lib/auth-context';
import type { ProductWithDetails } from '../types/database';

interface FavoriteWithProduct {
  id: string;
  product: ProductWithDetails;
}

export default function Favorites() {
  const { user } = useAuth();
  const [favorites, setFavorites] = useState<FavoriteWithProduct[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      fetchFavorites();
    } else {
      setLoading(false);
    }
  }, [user]);

  async function fetchFavorites() {
    const { data } = await supabase
      .from('favorites')
      .select(`
        id,
        product:products(
          *,
          category:categories(*),
          seller:profiles(*)
        )
      `)
      .eq('user_id', user!.id)
      .order('created_at', { ascending: false });

    if (data) {
      setFavorites(data as FavoriteWithProduct[]);
    }
    setLoading(false);
  }

  async function removeFavorite(favoriteId: string) {
    await supabase
      .from('favorites')
      .delete()
      .eq('id', favoriteId);
    setFavorites(prev => prev.filter(f => f.id !== favoriteId));
  }

  async function addToCart(productId: string) {
    if (!user) return;

    const { data: existing } = await supabase
      .from('cart_items')
      .select('*')
      .eq('user_id', user.id)
      .eq('product_id', productId)
      .maybeSingle();

    if (existing) {
      await supabase
        .from('cart_items')
        .update({ quantity: existing.quantity + 1 })
        .eq('id', existing.id);
    } else {
      await supabase
        .from('cart_items')
        .insert({
          user_id: user.id,
          product_id: productId,
          quantity: 1
        });
    }
  }

  if (!user) {
    return (
      <div className="py-12 text-center">
        <Heart className="w-16 h-16 text-gray-600 mx-auto mb-4" />
        <h2 className="text-xl font-semibold mb-2">Кіру қажет</h2>
        <p className="text-gray-400 mb-6">Таңдаулыларыңызды көру үшін жүйеге кіріңіз</p>
        <Link to="/login">
          <button className="btn-primary">Кіру</button>
        </Link>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="py-12">
        <div className="container-custom">
          <div className="skeleton h-8 w-40 mb-8" />
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="glass-card">
                <div className="skeleton aspect-square rounded-xl mb-4" />
                <div className="skeleton h-4 w-3/4 mb-2" />
                <div className="skeleton h-4 w-1/2" />
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="py-8 md:py-12">
      <div className="container-custom">
        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="heading-lg mb-8"
        >
          Таңдаулылар ({favorites.length})
        </motion.h1>

        {favorites.length === 0 ? (
          <div className="text-center py-12">
            <Heart className="w-16 h-16 text-gray-600 mx-auto mb-4" />
            <h2 className="text-xl font-semibold mb-2">Таңдаулылар бос</h2>
            <p className="text-gray-400 mb-6">Ұнайтын тауарларыңызды жазыңыз</p>
            <Link to="/catalog">
              <button className="btn-primary">Каталогқа өту</button>
            </Link>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            <AnimatePresence>
              {favorites.map((favorite, index) => (
                <motion.div
                  key={favorite.id}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.9 }}
                  transition={{ delay: index * 0.05 }}
                  className="relative"
                >
                  <Link to={`/product/${favorite.product.id}`}>
                    <div className="product-card">
                      <div className="relative aspect-square rounded-xl overflow-hidden mb-4 bg-slate-800/50">
                        {favorite.product.images[0] ? (
                          <img
                            src={favorite.product.images[0]}
                            alt={favorite.product.title}
                            className="product-card-image"
                          />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center">
                            <Sparkles className="w-16 h-16 text-gray-600" />
                          </div>
                        )}
                        {favorite.product.compare_price > favorite.product.price && (
                          <div className="absolute top-2 left-2 badge badge-danger">
                            -{Math.round((1 - favorite.product.price / favorite.product.compare_price) * 100)}%
                          </div>
                        )}
                      </div>
                      <h3 className="font-medium mb-1 line-clamp-2">{favorite.product.title}</h3>
                      <div className="flex items-center gap-1 mb-2">
                        <Star className="w-4 h-4 text-yellow-400 fill-yellow-400" />
                        <span className="text-sm text-gray-400">
                          {favorite.product.rating.toFixed(1)}
                        </span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-xl font-bold text-gradient">
                          {favorite.product.price.toLocaleString()} ₸
                        </span>
                        {favorite.product.compare_price > favorite.product.price && (
                          <span className="text-sm text-gray-500 line-through">
                            {favorite.product.compare_price.toLocaleString()} ₸
                          </span>
                        )}
                      </div>
                    </div>
                  </Link>

                  <div className="flex gap-2 mt-2">
                    <button
                      onClick={() => addToCart(favorite.product.id)}
                      className="btn-primary flex-1 flex items-center justify-center gap-1 text-sm py-2"
                    >
                      <ShoppingCart className="w-4 h-4" />
                      Себетке
                    </button>
                    <button
                      onClick={() => removeFavorite(favorite.id)}
                      className="btn-secondary px-3 py-2"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        )}
      </div>
    </div>
  );
}
