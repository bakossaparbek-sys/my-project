import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Plus,
  Edit2,
  Trash2,
  Package,
  Users,
  TrendingUp,
  DollarSign,
  X,
  Image,
  Save,
  Eye,
  EyeOff
} from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../lib/auth-context';
import type { Product, Category } from '../types/database';

export default function Admin() {
  const { user, profile } = useAuth();
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'overview' | 'products'>('overview');
  const [showProductModal, setShowProductModal] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [saving, setSaving] = useState(false);

  // Product form state
  const [productForm, setProductForm] = useState({
    title: '',
    description: '',
    price: '',
    compare_price: '',
    category_id: '',
    stock: '',
    images: [] as string[],
    imageUrls: ''
  });

  // Stats
  const [stats, setStats] = useState({
    totalProducts: 0,
    totalOrders: 0,
    totalRevenue: 0,
    totalCustomers: 0
  });

  useEffect(() => {
    if (user && (profile?.role === 'admin' || profile?.role === 'seller')) {
      fetchData();
    }
  }, [user, profile]);

  async function fetchData() {
    const [productsRes, categoriesRes, ordersRes] = await Promise.all([
      supabase
        .from('products')
        .select('*')
        .eq('seller_id', user!.id)
        .order('created_at', { ascending: false }),
      supabase
        .from('categories')
        .select('*')
        .order('name_kz'),
      supabase
        .from('orders')
        .select('total')
        .eq('payment_status', 'paid')
    ]);

    if (productsRes.data) setProducts(productsRes.data);
    if (categoriesRes.data) setCategories(categoriesRes.data);

    const revenue = ordersRes.data?.reduce((sum, order) => sum + Number(order.total), 0) || 0;

    setStats({
      totalProducts: productsRes.data?.length || 0,
      totalOrders: ordersRes.data?.length || 0,
      totalRevenue: revenue,
      totalCustomers: 0
    });

    setLoading(false);
  }

  function openNewProduct() {
    setEditingProduct(null);
    setProductForm({
      title: '',
      description: '',
      price: '',
      compare_price: '',
      category_id: '',
      stock: '',
      images: [],
      imageUrls: ''
    });
    setShowProductModal(true);
  }

  function openEditProduct(product: Product) {
    setEditingProduct(product);
    setProductForm({
      title: product.title,
      description: product.description,
      price: product.price.toString(),
      compare_price: product.compare_price.toString(),
      category_id: product.category_id || '',
      stock: product.stock.toString(),
      images: product.images,
      imageUrls: product.images.join('\n')
    });
    setShowProductModal(true);
  }

  async function saveProduct(e: React.FormEvent) {
    e.preventDefault();
    if (!user) return;

    setSaving(true);

    const images = productForm.imageUrls
      .split('\n')
      .map(url => url.trim())
      .filter(url => url.length > 0);

    const productData = {
      title: productForm.title,
      description: productForm.description,
      price: parseFloat(productForm.price),
      compare_price: productForm.compare_price ? parseFloat(productForm.compare_price) : 0,
      category_id: productForm.category_id || null,
      stock: parseInt(productForm.stock) || 0,
      images,
      seller_id: user.id,
      is_active: true
    };

    let error;
    if (editingProduct) {
      const result = await supabase
        .from('products')
        .update(productData)
        .eq('id', editingProduct.id);
      error = result.error;
    } else {
      const result = await supabase
        .from('products')
        .insert(productData);
      error = result.error;
    }

    if (!error) {
      setShowProductModal(false);
      fetchData();
    }

    setSaving(false);
  }

  async function deleteProduct(id: string) {
    if (!confirm('Осы тауарды жоясыз ба?')) return;

    await supabase
      .from('products')
      .delete()
      .eq('id', id);

    setProducts(prev => prev.filter(p => p.id !== id));
  }

  async function toggleProductVisibility(product: Product) {
    await supabase
      .from('products')
      .update({ is_active: !product.is_active })
      .eq('id', product.id);

    fetchData();
  }

  if (!user || (profile?.role !== 'admin' && profile?.role !== 'seller')) {
    return (
      <div className="py-12 text-center">
        <Package className="w-16 h-16 text-gray-600 mx-auto mb-4" />
        <h2 className="text-xl font-semibold mb-2">Рұқсат жоқ</h2>
        <p className="text-gray-400">Бұл бетке тек сатушылар қол жеткізе алады</p>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="py-12">
        <div className="container-custom">
          <div className="skeleton h-8 w-48 mb-8" />
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="glass-card">
                <div className="skeleton h-16 w-full" />
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="py-8 md:py-12">
      <div className="container-custom">
        <div className="flex items-center justify-between mb-8">
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="heading-lg"
          >
            Басқару панелі
          </motion.h1>
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={openNewProduct}
            className="btn-primary flex items-center gap-2"
          >
            <Plus className="w-5 h-5" />
            Жаңа тауар
          </motion.button>
        </div>

        {/* Tabs */}
        <div className="flex gap-2 mb-6">
          <button
            onClick={() => setActiveTab('overview')}
            className={`px-4 py-2 rounded-xl font-medium transition-all ${
              activeTab === 'overview'
                ? 'bg-blue-500/20 text-blue-300'
                : 'text-gray-400 hover:text-white hover:bg-white/5'
            }`}
          >
            Шолу
          </button>
          <button
            onClick={() => setActiveTab('products')}
            className={`px-4 py-2 rounded-xl font-medium transition-all ${
              activeTab === 'products'
                ? 'bg-blue-500/20 text-blue-300'
                : 'text-gray-400 hover:text-white hover:bg-white/5'
            }`}
          >
            Тауарлар ({products.length})
          </button>
        </div>

        {/* Overview */}
        {activeTab === 'overview' && (
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <div className="glass-card">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-blue-500/20 flex items-center justify-center">
                  <Package className="w-6 h-6 text-blue-400" />
                </div>
                <div>
                  <p className="text-2xl font-bold">{stats.totalProducts}</p>
                  <p className="text-sm text-gray-400">Тауарлар</p>
                </div>
              </div>
            </div>

            <div className="glass-card">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-emerald-500/20 flex items-center justify-center">
                  <TrendingUp className="w-6 h-6 text-emerald-400" />
                </div>
                <div>
                  <p className="text-2xl font-bold">{stats.totalOrders}</p>
                  <p className="text-sm text-gray-400">Тапсырыстар</p>
                </div>
              </div>
            </div>

            <div className="glass-card">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-amber-500/20 flex items-center justify-center">
                  <DollarSign className="w-6 h-6 text-amber-400" />
                </div>
                <div>
                  <p className="text-2xl font-bold">{stats.totalRevenue.toLocaleString()} ₸</p>
                  <p className="text-sm text-gray-400">Кіріс</p>
                </div>
              </div>
            </div>

            <div className="glass-card">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-red-500/20 flex items-center justify-center">
                  <Users className="w-6 h-6 text-red-400" />
                </div>
                <div>
                  <p className="text-2xl font-bold">{stats.totalCustomers}</p>
                  <p className="text-sm text-gray-400">Клиенттер</p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Products List */}
        {activeTab === 'products' && (
          <div className="glass rounded-2xl overflow-hidden">
            {products.length === 0 ? (
              <div className="p-12 text-center">
                <Package className="w-16 h-16 text-gray-600 mx-auto mb-4" />
                <h3 className="text-xl font-semibold mb-2">Тауарлар жоқ</h3>
                <p className="text-gray-400 mb-6">Алғашқы тауарыңызды қосыңыз</p>
                <button onClick={openNewProduct} className="btn-primary">
                  Жаңа тауар қосу
                </button>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-white/5">
                    <tr>
                      <th className="px-6 py-4 text-left text-sm font-medium text-gray-400">Тауар</th>
                      <th className="px-6 py-4 text-left text-sm font-medium text-gray-400">Баға</th>
                      <th className="px-6 py-4 text-left text-sm font-medium text-gray-400">Қор</th>
                      <th className="px-6 py-4 text-left text-sm font-medium text-gray-400">Статус</th>
                      <th className="px-6 py-4 text-right text-sm font-medium text-gray-400">Әрекет</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/5">
                    {products.map(product => (
                      <tr key={product.id} className="hover:bg-white/5 transition-colors">
                        <td className="px-6 py-4">
                          <div className="flex items-center gap-3">
                            <div className="w-12 h-12 rounded-xl overflow-hidden bg-slate-800 flex-shrink-0">
                              {product.images[0] ? (
                                <img
                                  src={product.images[0]}
                                  alt={product.title}
                                  className="w-full h-full object-cover"
                                />
                              ) : (
                                <div className="w-full h-full flex items-center justify-center">
                                  <Image className="w-5 h-5 text-gray-600" />
                                </div>
                              )}
                            </div>
                            <div>
                              <p className="font-medium line-clamp-1">{product.title}</p>
                              <p className="text-sm text-gray-400">
                                {product.rating.toFixed(1)} ★ ({product.reviews_count})
                              </p>
                            </div>
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <p className="font-semibold">{product.price.toLocaleString()} ₸</p>
                          {product.compare_price > product.price && (
                            <p className="text-sm text-gray-500 line-through">
                              {product.compare_price.toLocaleString()} ₸
                            </p>
                          )}
                        </td>
                        <td className="px-6 py-4">
                          <span className={product.stock < 10 ? 'text-red-400' : ''}>
                            {product.stock}
                          </span>
                        </td>
                        <td className="px-6 py-4">
                          <span className={`badge ${product.is_active ? 'badge-success' : 'badge-warning'}`}>
                            {product.is_active ? 'Белсенді' : 'Құпия'}
                          </span>
                        </td>
                        <td className="px-6 py-4">
                          <div className="flex items-center justify-end gap-2">
                            <button
                              onClick={() => toggleProductVisibility(product)}
                              className="p-2 hover:bg-white/10 rounded-lg transition-colors"
                              title={product.is_active ? 'Жасыру' : 'Көрсету'}
                            >
                              {product.is_active ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                            </button>
                            <button
                              onClick={() => openEditProduct(product)}
                              className="p-2 hover:bg-white/10 rounded-lg transition-colors"
                            >
                              <Edit2 className="w-4 h-4" />
                            </button>
                            <button
                              onClick={() => deleteProduct(product.id)}
                              className="p-2 hover:bg-red-500/10 rounded-lg transition-colors text-red-400"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}

        {/* Product Modal */}
        <AnimatePresence>
          {showProductModal && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto"
              onClick={() => setShowProductModal(false)}
            >
              <motion.div
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.9, opacity: 0 }}
                onClick={(e) => e.stopPropagation()}
                className="glass-card max-w-2xl w-full my-8"
              >
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-2xl font-semibold">
                    {editingProduct ? 'Тауарды өңдеу' : 'Жаңа тауар'}
                  </h3>
                  <button
                    onClick={() => setShowProductModal(false)}
                    className="p-2 hover:bg-white/10 rounded-lg transition-colors"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                <form onSubmit={saveProduct} className="space-y-6">
                  <div>
                    <label className="block text-sm font-medium mb-2">Тақырып *</label>
                    <input
                      type="text"
                      value={productForm.title}
                      onChange={(e) => setProductForm(prev => ({ ...prev, title: e.target.value }))}
                      required
                      className="glass-input"
                      placeholder="Тауар атауы"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-2">Сипаттама</label>
                    <textarea
                      value={productForm.description}
                      onChange={(e) => setProductForm(prev => ({ ...prev, description: e.target.value }))}
                      rows={4}
                      className="glass-input resize-none"
                      placeholder="Тауар сипаттамасы"
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                      <label className="block text-sm font-medium mb-2">Баға (₸) *</label>
                      <input
                        type="number"
                        value={productForm.price}
                        onChange={(e) => setProductForm(prev => ({ ...prev, price: e.target.value }))}
                        required
                        min="0"
                        className="glass-input"
                        placeholder="0"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2">Салыстыру бағасы</label>
                      <input
                        type="number"
                        value={productForm.compare_price}
                        onChange={(e) => setProductForm(prev => ({ ...prev, compare_price: e.target.value }))}
                        min="0"
                        className="glass-input"
                        placeholder="0"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2">Қор</label>
                      <input
                        type="number"
                        value={productForm.stock}
                        onChange={(e) => setProductForm(prev => ({ ...prev, stock: e.target.value }))}
                        min="0"
                        className="glass-input"
                        placeholder="0"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-2">Санат</label>
                    <select
                      value={productForm.category_id}
                      onChange={(e) => setProductForm(prev => ({ ...prev, category_id: e.target.value }))}
                      className="glass-input"
                    >
                      <option value="">Таңдаңыз</option>
                      {categories.map(category => (
                        <option key={category.id} value={category.id} className="bg-slate-900">
                          {category.name_kz}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-2">
                      Суреттер (әр жолға бір URL)
                    </label>
                    <textarea
                      value={productForm.imageUrls}
                      onChange={(e) => setProductForm(prev => ({ ...prev, imageUrls: e.target.value }))}
                      rows={3}
                      className="glass-input resize-none font-mono text-sm"
                      placeholder="https://example.com/image1.jpg&#10;https://example.com/image2.jpg"
                    />
                    <p className="text-xs text-gray-500 mt-1">
                      Pexels суреттерді пайдалануға болады
                    </p>
                  </div>

                  <div className="flex gap-3">
                    <button
                      type="button"
                      onClick={() => setShowProductModal(false)}
                      className="btn-secondary flex-1"
                    >
                      Бас тарту
                    </button>
                    <button
                      type="submit"
                      disabled={saving}
                      className="btn-primary flex-1 flex items-center justify-center gap-2"
                    >
                      <Save className="w-4 h-4" />
                      {saving ? 'Сақтауда...' : 'Сақтау'}
                    </button>
                  </div>
                </form>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
