import { Outlet, Link, useLocation, useNavigate } from 'react-router-dom';
import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useAuth } from '../lib/auth-context';
import {
  ShoppingCart,
  Heart,
  MessageCircle,
  User,
  Search,
  Menu,
  X,
  Package,
  LogOut,
  Settings,
  LayoutDashboard,
  Store,
  ChevronDown
} from 'lucide-react';
import { supabase } from '../lib/supabase';
import type { CartItemWithProduct } from '../types/database';

export default function Layout() {
  const { user, profile, signOut } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [userMenuOpen, setUserMenuOpen] = useState(false);
  const [cartCount, setCartCount] = useState(0);
  const [favoriteCount, setFavoriteCount] = useState(0);
  const [unreadMessages, setUnreadMessages] = useState(0);

  useEffect(() => {
    if (user) {
      fetchCartCount();
      fetchFavoriteCount();
      fetchUnreadMessages();
    }
  }, [user]);

  useEffect(() => {
    const handleClickOutside = () => {
      setUserMenuOpen(false);
    };
    document.addEventListener('click', handleClickOutside);
    return () => document.removeEventListener('click', handleClickOutside);
  }, []);

  async function fetchCartCount() {
    const { data } = await supabase
      .from('cart_items')
      .select('quantity')
      .eq('user_id', user!.id);
    const count = data?.reduce((sum, item) => sum + item.quantity, 0) || 0;
    setCartCount(count);
  }

  async function fetchFavoriteCount() {
    const { count } = await supabase
      .from('favorites')
      .select('*', { count: 'exact', head: true })
      .eq('user_id', user!.id);
    setFavoriteCount(count || 0);
  }

  async function fetchUnreadMessages() {
    const { data } = await supabase
      .from('chat_rooms')
      .select('id')
      .or(`buyer_id.eq.${user!.id},seller_id.eq.${user!.id}`);

    if (data && data.length > 0) {
      const roomIds = data.map(r => r.id);
      const { count } = await supabase
        .from('chat_messages')
        .select('*', { count: 'exact', head: true })
        .in('room_id', roomIds)
        .eq('read_at', null)
        .neq('sender_id', user!.id);
      setUnreadMessages(count || 0);
    }
  }

  async function handleSearch(e: React.FormEvent) {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/catalog?search=${encodeURIComponent(searchQuery.trim())}`);
      setSearchOpen(false);
      setSearchQuery('');
    }
  }

  async function handleSignOut() {
    await signOut();
    navigate('/');
  }

  const navItems = [
    { path: '/', label: 'Басты бет' },
    { path: '/catalog', label: 'Каталог' },
  ];

  return (
    <div className="min-h-screen flex flex-col">
      {/* Header */}
      <header className="fixed top-0 left-0 right-0 z-50 glass-dark">
        <div className="container-custom">
          <div className="flex items-center justify-between h-16 md:h-20">
            {/* Logo */}
            <Link to="/" className="flex items-center gap-2 group">
              <motion.div
                className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-500 to-cyan-500 flex items-center justify-center shadow-glow"
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.95 }}
              >
                <Store className="w-6 h-6 text-white" />
              </motion.div>
              <span className="text-xl font-bold hidden sm:block">
                <span className="text-gradient">LesGo</span>
                <span className="text-gray-300 ml-1">Market</span>
              </span>
            </Link>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex items-center gap-1">
              {navItems.map((item) => (
                <Link
                  key={item.path}
                  to={item.path}
                  className={`px-4 py-2 rounded-xl font-medium transition-all duration-300 ${
                    location.pathname === item.path
                      ? 'bg-blue-500/20 text-blue-300'
                      : 'text-gray-300 hover:text-white hover:bg-white/5'
                  }`}
                >
                  {item.label}
                </Link>
              ))}
            </nav>

            {/* Search Bar - Desktop */}
            <div className="hidden md:block flex-1 max-w-md mx-8">
              <form onSubmit={handleSearch} className="relative">
                <Search className="input-icon-left w-5 h-5" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Іздеу..."
                  className="glass-input pl-10 pr-4 py-2.5"
                />
              </form>
            </div>

            {/* Right Actions */}
            <div className="flex items-center gap-2">
              {/* Mobile Search Toggle */}
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setSearchOpen(!searchOpen)}
                className="md:hidden p-2 glass-button rounded-xl"
              >
                <Search className="w-5 h-5" />
              </motion.button>

              {user ? (
                <>
                  {/* Favorites */}
                  <Link to="/favorites">
                    <motion.div
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      className="relative p-2 glass-button rounded-xl"
                    >
                      <Heart className="w-5 h-5" />
                      {favoriteCount > 0 && (
                        <span className="absolute -top-1 -right-1 w-5 h-5 bg-blue-500 rounded-full text-xs font-bold flex items-center justify-center">
                          {favoriteCount}
                        </span>
                      )}
                    </motion.div>
                  </Link>

                  {/* Cart */}
                  <Link to="/cart">
                    <motion.div
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      className="relative p-2 glass-button rounded-xl"
                    >
                      <ShoppingCart className="w-5 h-5" />
                      {cartCount > 0 && (
                        <span className="absolute -top-1 -right-1 w-5 h-5 bg-blue-500 rounded-full text-xs font-bold flex items-center justify-center">
                          {cartCount}
                        </span>
                      )}
                    </motion.div>
                  </Link>

                  {/* Chat */}
                  <Link to="/chat">
                    <motion.div
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      className="relative p-2 glass-button rounded-xl"
                    >
                      <MessageCircle className="w-5 h-5" />
                      {unreadMessages > 0 && (
                        <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 rounded-full text-xs font-bold flex items-center justify-center">
                          {unreadMessages}
                        </span>
                      )}
                    </motion.div>
                  </Link>

                  {/* User Menu */}
                  <div className="relative">
                    <motion.button
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      onClick={(e) => {
                        e.stopPropagation();
                        setUserMenuOpen(!userMenuOpen);
                      }}
                      className="flex items-center gap-2 p-2 glass-button rounded-xl"
                    >
                      <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-blue-500 to-cyan-500 flex items-center justify-center text-sm font-bold">
                        {profile?.full_name?.[0] || profile?.email?.[0] || 'U'}
                      </div>
                      <ChevronDown className="w-4 h-4 hidden sm:block" />
                    </motion.button>

                    <AnimatePresence>
                      {userMenuOpen && (
                        <motion.div
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, y: 10 }}
                          className="absolute right-0 top-full mt-2 w-56 glass-card p-2 z-50"
                        >
                          <div className="px-3 py-2 border-b border-white/10 mb-2">
                            <p className="font-medium">{profile?.full_name || 'Қолданушы'}</p>
                            <p className="text-sm text-gray-400">{profile?.email}</p>
                          </div>
                          <Link
                            to="/profile"
                            onClick={() => setUserMenuOpen(false)}
                            className="flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-white/10 transition-colors"
                          >
                            <User className="w-4 h-4" />
                            <span>Профиль</span>
                          </Link>
                          <Link
                            to="/orders"
                            onClick={() => setUserMenuOpen(false)}
                            className="flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-white/10 transition-colors"
                          >
                            <Package className="w-4 h-4" />
                            <span>Тапсырыстар</span>
                          </Link>
                          {profile?.role === 'admin' && (
                            <Link
                              to="/admin"
                              onClick={() => setUserMenuOpen(false)}
                              className="flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-white/10 transition-colors"
                            >
                              <LayoutDashboard className="w-4 h-4" />
                              <span>Админ панелі</span>
                            </Link>
                          )}
                          {(profile?.role === 'seller' || profile?.role === 'admin') && (
                            <Link
                              to="/admin"
                              onClick={() => setUserMenuOpen(false)}
                              className="flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-white/10 transition-colors"
                            >
                              <Settings className="w-4 h-4" />
                              <span>Сатушы панелі</span>
                            </Link>
                          )}
                          <div className="divider" />
                          <button
                            onClick={handleSignOut}
                            className="flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-white/10 transition-colors w-full text-left text-red-400"
                          >
                            <LogOut className="w-4 h-4" />
                            <span>Шығу</span>
                          </button>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                </>
              ) : (
                <div className="flex items-center gap-2">
                  <Link to="/login">
                    <motion.button
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      className="btn-secondary"
                    >
                      Кіру
                    </motion.button>
                  </Link>
                  <Link to="/register" className="hidden sm:block">
                    <motion.button
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      className="btn-primary"
                    >
                      Тіркелу
                    </motion.button>
                  </Link>
                </div>
              )}

              {/* Mobile Menu Toggle */}
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="md:hidden p-2 glass-button rounded-xl"
              >
                {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
              </motion.button>
            </div>
          </div>
        </div>

        {/* Mobile Search */}
        <AnimatePresence>
          {searchOpen && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="md:hidden overflow-hidden"
            >
              <div className="container-custom pb-4">
                <form onSubmit={handleSearch} className="relative">
                  <Search className="input-icon-left w-5 h-5" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Іздеу..."
                    className="glass-input pl-10 pr-4"
                    autoFocus
                  />
                </form>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </header>

      {/* Mobile Menu Overlay */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-40 bg-black/60 backdrop-blur-sm md:hidden"
            onClick={() => setMobileMenuOpen(false)}
          >
            <motion.div
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'tween' }}
              className="absolute right-0 top-0 bottom-0 w-64 glass-dark p-6 pt-20"
              onClick={(e) => e.stopPropagation()}
            >
              <nav className="flex flex-col gap-2">
                {navItems.map((item) => (
                  <Link
                    key={item.path}
                    to={item.path}
                    onClick={() => setMobileMenuOpen(false)}
                    className={`px-4 py-3 rounded-xl font-medium transition-all ${
                      location.pathname === item.path
                        ? 'bg-blue-500/20 text-blue-300'
                        : 'text-gray-300 hover:text-white hover:bg-white/5'
                    }`}
                  >
                    {item.label}
                  </Link>
                ))}
                <div className="divider" />
                {user ? (
                  <>
                    <Link
                      to="/favorites"
                      onClick={() => setMobileMenuOpen(false)}
                      className="flex items-center gap-3 px-4 py-3 rounded-lg hover:bg-white/10 transition-colors text-gray-300 hover:text-white"
                    >
                      <Heart className="w-5 h-5" />
                      <span>Таңдаулылар</span>
                    </Link>
                    <Link
                      to="/cart"
                      onClick={() => setMobileMenuOpen(false)}
                      className="flex items-center gap-3 px-4 py-3 rounded-lg hover:bg-white/10 transition-colors text-gray-300 hover:text-white"
                    >
                      <ShoppingCart className="w-5 h-5" />
                      <span>Себет</span>
                    </Link>
                    <Link
                      to="/chat"
                      onClick={() => setMobileMenuOpen(false)}
                      className="flex items-center gap-3 px-4 py-3 rounded-lg hover:bg-white/10 transition-colors text-gray-300 hover:text-white"
                    >
                      <MessageCircle className="w-5 h-5" />
                      <span>Чат</span>
                    </Link>
                    <Link
                      to="/orders"
                      onClick={() => setMobileMenuOpen(false)}
                      className="flex items-center gap-3 px-4 py-3 rounded-lg hover:bg-white/10 transition-colors text-gray-300 hover:text-white"
                    >
                      <Package className="w-5 h-5" />
                      <span>Тапсырыстар</span>
                    </Link>
                    {profile?.role === 'admin' && (
                      <Link
                        to="/admin"
                        onClick={() => setMobileMenuOpen(false)}
                        className="flex items-center gap-3 px-4 py-3 rounded-lg hover:bg-white/10 transition-colors text-gray-300 hover:text-white"
                      >
                        <LayoutDashboard className="w-5 h-5" />
                        <span>Админ</span>
                      </Link>
                    )}
                    <div className="divider" />
                    <button
                      onClick={() => {
                        setMobileMenuOpen(false);
                        handleSignOut();
                      }}
                      className="flex items-center gap-3 px-4 py-3 rounded-lg hover:bg-white/10 transition-colors text-red-400 w-full text-left"
                    >
                      <LogOut className="w-5 h-5" />
                      <span>Шығу</span>
                    </button>
                  </>
                ) : (
                  <>
                    <Link
                      to="/login"
                      onClick={() => setMobileMenuOpen(false)}
                      className="btn-secondary text-center"
                    >
                      Кіру
                    </Link>
                    <Link
                      to="/register"
                      onClick={() => setMobileMenuOpen(false)}
                      className="btn-primary text-center"
                    >
                      Тіркелу
                    </Link>
                  </>
                )}
              </nav>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main Content */}
      <main className="flex-1 pt-16 md:pt-20">
        <Outlet />
      </main>

      {/* Footer */}
      <footer className="glass-dark mt-auto">
        <div className="container-custom py-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-500 to-cyan-500 flex items-center justify-center">
                  <Store className="w-6 h-6 text-white" />
                </div>
                <span className="text-xl font-bold">
                  <span className="text-gradient">LesGo</span>
                  <span className="text-gray-300 ml-1">Market</span>
                </span>
              </div>
              <p className="text-gray-400 text-sm">
                Қазақстандық люкс маркетплейс. Сапалы тауарлар мен қызметтер.
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Сатып алушыларға</h4>
              <ul className="space-y-2 text-sm text-gray-400">
                <li><a href="#" className="hover:text-white transition-colors">Қалай сатып алуға болады</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Төлем әдістері</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Жеткізу</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Қайтару саясаты</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Сатушыларға</h4>
              <ul className="space-y-2 text-sm text-gray-400">
                <li><a href="#" className="hover:text-white transition-colors">Сатушы болу</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Құралдар</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Комиссия</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Кездеңдіру</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Байланыс</h4>
              <ul className="space-y-2 text-sm text-gray-400">
                <li><a href="mailto:support@lesgo.kz" className="hover:text-white transition-colors">support@lesgo.kz</a></li>
                <li><a href="tel:+77771234567" className="hover:text-white transition-colors">+7 777 123 45 67</a></li>
              </ul>
            </div>
          </div>
          <div className="divider" />
          <div className="flex flex-col md:flex-row items-center justify-between gap-4 text-sm text-gray-400">
            <p>© 2024 LesGo Marketplace. Барлық құқықтар қорғалған.</p>
            <div className="flex gap-4">
              <a href="#" className="hover:text-white transition-colors">Құпиялылық</a>
              <a href="#" className="hover:text-white transition-colors">Шарттар</a>
              <a href="#" className="hover:text-white transition-colors">Cookie</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
